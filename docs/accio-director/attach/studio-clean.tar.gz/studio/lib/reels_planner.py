"""reels_planner: календарь рилсов на месяц (15 тем x 2 = 30 роликов): тема, хук, шот-лист 3–5 шотов, промпт каждого шота, подпись.
Правила Beautyarts проверяются lint-ом; нарушения -> перегенерация (<=2) -> шаблон."""
import json, csv, datetime, itertools
from pathlib import Path
from . import core, rules

PRODUCT = rules.PRODUCT

# Шаблоны тем (режим template, $0). Тексты без цен и тех. параметров, продукт только «ZISHÉL Glam».
TOPICS = [
 ("silk", "Чёрный шёлк", ["Шёлк, который хочется трогать взглядом", "Когда красота — это тишина и блеск"], "black silk fabric flowing slowly in soft light, glints sweeping across the folds", "Эстетика {p}: глубокий чёрный шёлк и мягкий блеск."),
 ("ritual", "Ритуал красоты", ["Ваш вечерний ритуал — это про вас", "Маленький ритуал, который меняет настроение"], "elegant evening beauty ritual atmosphere, warm candle-like glow, slow movement", "{p} — часть вашего ритуала красоты."),
 ("confidence", "Уверенность", ["Уверенность начинается с решения", "Empower your confidence"], "confident editorial mood, dark elegant backdrop, slow cinematic push-in", "{p}: про уверенность в себе."),
 ("design", "Design your body", ["Design your body — это ваш выбор", "Вы сами выбираете, как выглядеть"], "luxury product reveal, soft rim light tracing the box edges", "{p} — Design your body."),
 ("detail", "Детали упаковки", ["Детали, которые видно только вблизи", "Смотрите внимательно: всё в деталях"], "macro slow glide across embossed lettering and silver foil edges of the box", "Упаковка {p} — внимание к каждой детали."),
 ("clinic", "В клинике", ["Как проходит приём — спокойно и уютно", "Атмосфера клиники Art Medical"], "calm premium clinic ambience, soft reflections on dark glass, slow camera drift", "{p} в атмосфере клиники Art Medical."),
 ("petals", "Лепестки и шёлк", ["Нежность в тёмной палитре", "Контраст, который завораживает"], "pink flower petals drift gently over black silk beside the box, slow drift", "{p} и нежность лепестков."),
 ("light", "Игра света", ["Свет, который рисует форму", "Блики, от которых не оторваться"], "sparkling highlights glide over the glossy box surface, slow camera orbit", "Игра света на упаковке {p}."),
 ("editorial", "Эдиториал", ["Как с обложки журнала", "Редакционный стиль в каждом кадре"], "editorial fashion look, dark flowing fabric moving behind, subtle camera push", "Эдиториал {p}."),
 ("morning", "Утро", ["Утро, в котором вы себе нравитесь", "Начните день с красоты"], "soft morning light slowly crossing the product on dark fabric", "Утро с {p}."),
 ("gift", "Подарок себе", ["Вы заслуживаете заботы о себе", "Подарите себе красивое решение"], "gift-like reveal, silk ribbon-like fabric ripples around the box, slow push-in", "{p} — забота о себе."),
 ("story", "История бренда", ["Бренд, который говорит красиво и тихо", "ZISHÉL Glam — это стиль"], "brand story montage feel, slow dolly past the box and logo reflections", "История {p}."),
 ("mood", "Настроение", ["Настроение дня: чёрный, серебро, роза", "Три цвета — одно настроение"], "moody dark palette with silver highlights and a touch of rose, slow drift", "Настроение {p}."),
 ("close", "Крупным планом", ["Подойдём поближе", "Крупный план, который говорит сам за себя"], "extreme close up slow pan along the box surface texture and lettering", "{p} крупным планом."),
 ("invite", "Приглашение", ["Расскажем подробнее — напишите нам", "Хотите узнать больше? Мы на связи"], "inviting final reveal, product centered, light sweeps once across the silk", "Хотите узнать о {p} больше? Напишите нам в Direct."),
]
SHOT_MOVES = ["slow push-in toward the product", "gentle orbit to the right revealing the side of the box", "macro glide over the lettering and edge highlights",
              "slow pull-back revealing the full composition", "soft rack focus from fabric folds to the box"]
HASH = ["#ZISHÉLGlam", "#ArtMedical", "#Beautyarts", "#Алматы", "#эстетика", "#красота"]

def template_reels(topics, products, n_shots=4, seg_seconds=4):
    reels = []
    for rnd in range(2):
        for ti, (tid, title, hooks, base, cap) in enumerate(topics):
            prod_img = products[(ti * 2 + rnd) % len(products)] if products else None
            shots = []
            for k in range(n_shots):
                move = SHOT_MOVES[(k + rnd) % len(SHOT_MOVES)]
                shots.append({"n": k + 1, "duration": seg_seconds,
                              "prompt": f"Luxury cosmetics brand video, the product box lies on black silk. {base}. Camera: {move}. The box, its lettering and logo stay perfectly sharp and unchanged. Dark elegant palette, silver highlights, cinematic."})
            reels.append({"topic_id": tid, "topic": title, "variant": rnd + 1, "hook": hooks[rnd], "product_image": str(prod_img) if prod_img else None,
                          "shots": shots, "caption": cap.format(p=PRODUCT), "hashtags": HASH})
    return reels

LLM_SYS = ("Ты сценарист коротких рилсов бренда Beautyarts / Art Medical (Алматы). Пиши по-русски. Правила: цены не называть; продукт называется ТОЛЬКО «ZISHÉL Glam» (никак иначе); "
           "слов «Fishbone» и «распродажа» нет; без технических параметров (мл, %, мг, концентрации, состав) в текстах; без подиумов и подставок в предметке. Только JSON.")

def llm_reel(ctx, topic, variant, n_shots, seg_seconds, feedback=""):
    prompt = (f"Тема: {topic[1]}. Настроение: {topic[3]}. Вариант {variant} из 2 (сделай отличающийся от другого).\n"
              f"Верни JSON: {{\"hook\": \"<=60 симв, русский\", \"shots\": [{{\"prompt\": \"English video prompt for image-to-video, camera move + light, product box on black silk, text stays unchanged, no podium\"}} x{n_shots}], "
              f"\"caption\": \"<=180 симв, русский, с призывом написать в Direct\", \"hashtags\": [\"...\" x6]}}. {feedback}")
    role = ctx.reg.roles["llm"]
    res, out, usd, hit = core.call(ctx, role, {"prompt": prompt, "system": LLM_SYS}, tag=f"plan:{topic[0]}:{variant}", use_cache=False)
    return core.extract_json(out), usd

def lint_reel(r):
    v = []
    for t in (r["hook"], r["caption"], " ".join(r["hashtags"])):
        v += rules.lint(t, "sales")
    for s in r["shots"]:
        v += rules.lint(s["prompt"], "prompt")
    return v

def plan(ctx):
    cfg = ctx.job.get("reels", {})
    n_shots = int(cfg.get("shots_per_reel", 4)); seg = int(cfg.get("seg_seconds", 4))
    from .photo_enhance import list_images
    products = list_images(ctx.job["input_dir"]) if ctx.job.get("input_dir") else []
    topics = list(TOPICS)
    if cfg.get("topics"):   # свои темы из job.yaml: [{id,title,hooks[2],mood,caption}]
        topics = [(t["id"], t["title"], t["hooks"], t["mood"], t["caption"]) for t in cfg["topics"]]
    reels = template_reels(topics, products, n_shots, seg)
    usd = 0.0
    if cfg.get("planner", "template") == "llm" and ctx.go:
        for r in reels[: int(cfg.get("llm_limit", len(reels)))]:
            topic = next(t for t in topics if t[0] == r["topic_id"])
            fb = ""
            for attempt in range(3):
                try:
                    j, u = llm_reel(ctx, topic, r["variant"], n_shots, seg, fb); usd += u
                    cand = dict(r); cand["hook"] = j["hook"]; cand["caption"] = rules.fix_product_name(j["caption"]); cand["hashtags"] = j.get("hashtags", HASH)
                    cand["shots"] = [{"n": i + 1, "duration": seg, "prompt": rules.guard_prompt(s["prompt"], ctx.rules)} for i, s in enumerate(j["shots"][:n_shots])]
                    viol = lint_reel(cand)
                    if not viol and len(cand["shots"]) >= 3:
                        r.update(cand); r["source"] = "llm"; break
                    fb = "Исправь нарушения: " + "; ".join(viol)
                except core.BudgetExceeded: raise
                except Exception as e:
                    fb = f"Верни валидный JSON ({repr(e)[:80]})"
            else:
                r["source"] = "template(llm-lint-fail)"
    start = datetime.date.fromisoformat(str(cfg.get("start_date", "2026-11-01")))
    # календарь: 1-й вариант каждой темы в дни 1..15, 2-й — 16..30
    for i, r in enumerate(reels):
        r["day"] = i + 1
        r["date"] = (start + datetime.timedelta(days=i)).isoformat()
        r["time"] = cfg.get("post_time", "19:00") + " (Asia/Qyzylorda)"
        r["id"] = f"D{i+1:02d}_{r['topic_id']}_v{r['variant']}"
        r["lint"] = lint_reel(r)
        r.setdefault("source", "template")
    outdir = ctx.out / "reels_plan"; outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "calendar.json").write_text(json.dumps(reels, ensure_ascii=False, indent=1))
    with open(outdir / "calendar.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["день", "дата", "время", "тема", "хук", "шотов", "подпись", "хэштеги", "lint"])
        for r in reels: w.writerow([r["day"], r["date"], r["time"], r["topic"], r["hook"], len(r["shots"]), r["caption"], " ".join(r["hashtags"]), "; ".join(r["lint"]) or "ok"])
    md = ["# Календарь рилсов (%d)\n" % len(reels)]
    for r in reels:
        md.append(f"## {r['date']} — {r['topic']} (вариант {r['variant']})\n**Хук:** {r['hook']}\n\n**Подпись:** {r['caption']}\n\n" + "\n".join(f"{s['n']}. ({s['duration']} с) {s['prompt']}" for s in r["shots"]) + f"\n\nlint: {'; '.join(r['lint']) or 'ok'}\n")
    (outdir / "calendar.md").write_text("\n".join(md), encoding="utf-8")
    return {"reels": reels, "usd": usd, "dir": str(outdir), "lint_fail": sum(1 for r in reels if r["lint"])}
