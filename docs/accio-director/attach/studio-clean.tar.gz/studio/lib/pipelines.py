"""Сборка этапов: продовые видео (hero), мини-ролики из фото (сцены), рилсы по календарю, продолжение клипа."""
import json, shutil
from pathlib import Path
from . import core, clip_chain, stitch, photo_enhance, reels_planner, rules

def _stitch_cfg(ctx, extra=None):
    c = dict(ctx.job.get("stitch", {}))
    c.update(extra or {})
    return c

def _final(ctx, name, segs, outdir, scfg=None):
    out = Path(outdir) / f"{name}.mp4"
    rep = stitch.stitch(segs, out, _stitch_cfg(ctx, scfg), work=Path(outdir) / "_work" / name, ctx=ctx)
    joints = [j["out_frame"] for j in rep["joints"] if "out_frame" in j]
    sr = stitch.seam_report(out if rep.get("upscale") is None else out, joints, Path(outdir) / "seams" / name, label=name) if joints else None
    return rep, sr

def run_continue(ctx):
    """Продолжить существующий клип (start_video) N сегментами от его РЕАЛЬНОГО последнего кадра и склеить всё в один файл."""
    cfg = ctx.job["continue"]
    outdir = ctx.out / "continue"; outdir.mkdir(parents=True, exist_ok=True)
    name = cfg.get("name", "cont")
    if cfg.get("start_video"):
        kf = core.last_frame(cfg["start_video"], outdir / f"{name}_start_last.png")
        pre = [Path(cfg["start_video"])]
    else:
        kf, pre = Path(cfg["keyframe"]), []
    shots = [{"keyframe": kf, "prompt": p, "duration": cfg.get("seg_seconds", 3)} for p in cfg["prompts"][: int(cfg.get("segments", 3))]]
    ch = clip_chain.run_chain(ctx, name, shots, outdir, cfg)
    je = clip_chain.join_errors(pre + ch["segments"]) if len(pre + ch["segments"]) > 1 else []
    rep, sr = _final(ctx, name, pre + ch["segments"], outdir)
    # то же без исходного клипа: только сгенерённая цепочка
    rep2, sr2 = _final(ctx, name + "_chain_only", ch["segments"], outdir) if len(ch["segments"]) > 1 else (None, None)
    return {"chain": ch, "join_mse_raw": je, "stitch": rep, "seams": sr, "stitch_chain_only": rep2, "seams_chain_only": sr2}

def run_hero(ctx):
    cfg = ctx.job["hero_videos"]
    outdir = ctx.out / "hero"; outdir.mkdir(parents=True, exist_ok=True)
    src = ctx.out / "photos"
    imgs = sorted(src.glob("*__enhance.jpg")) if src.exists() and list(src.glob("*__enhance.jpg")) else photo_enhance.list_images(ctx.job["input_dir"])
    seg_s = int(cfg.get("seg_seconds", 5)); nseg = max(1, int(cfg.get("seconds", 45)) // seg_s)
    results = []
    for v in range(int(cfg.get("count", 3))):
        sel = [imgs[(v * nseg + k) % len(imgs)] for k in range(nseg + 1)]
        base = cfg.get("style_prompts") or ["Slow cinematic camera move, the scene gently evolves, natural motion"]
        shots = []
        for k in range(nseg):
            shots.append({"keyframe": core.prep_image(sel[0], ctx.job_dir / "work" / "prep" / f"{Path(sel[0]).stem}.jpg", 2048) if k == 0 else None,
                          "end_keyframe": core.prep_image(sel[k + 1], ctx.job_dir / "work" / "prep" / f"{Path(sel[k+1]).stem}.jpg", 2048),
                          "prompt": base[k % len(base)], "duration": seg_s})
        name = f"hero{v+1}"
        ch = clip_chain.run_chain(ctx, name, shots, outdir, cfg)
        rep, sr = _final(ctx, name, ch["segments"], outdir, cfg.get("stitch"))
        results.append({"name": name, "chain_usd": ch["usd"], "report": rep["output"], "drift": ch["drift"]})
    return results

def run_minis(ctx):
    cfg = ctx.job["minis"]
    outdir = ctx.out / "minis"; outdir.mkdir(parents=True, exist_ok=True)
    imgs = photo_enhance.list_images(ctx.job["input_dir"])
    scenes = cfg["scenes"]
    count = int(cfg.get("count", len(scenes)))
    res = []
    for i in range(count):
        src = imgs[i % len(imgs)]; scene = scenes[i % len(scenes)]
        stem = f"mini{i+1:02d}"
        variant = {"name": f"scene_{stem}", "prompt": rules.guard_prompt(photo_enhance.SCENE.format(bg=scene["still"]), ctx.rules), "bg": scene["still"]}
        rec = photo_enhance.process_one(ctx, src, variant, {**ctx.job.get("enhance", {}), **cfg.get("enhance", {})}, outdir)
        if rec.get("status") not in ("ok", "qc_flagged"): res.append({"name": stem, "status": rec.get("status")}); continue
        kf = Path(rec["out"])
        segs_n = int(cfg.get("segments", 2)); sec = int(cfg.get("seg_seconds", 4))
        prompts = scene.get("motion") or ["gentle natural motion, people smile and look around, snow/light moves softly"]
        shots = [{"keyframe": kf if k == 0 else None, "prompt": prompts[k % len(prompts)], "duration": sec} for k in range(segs_n)]
        ch = clip_chain.run_chain(ctx, stem, shots, outdir / stem, cfg)
        rep, sr = _final(ctx, stem, ch["segments"], outdir / stem) if len(ch["segments"]) > 1 else (None, None)
        res.append({"name": stem, "scene": scene["name"], "still": str(kf), "video": rep["output"] if rep else str(ch["segments"][0])})
    return res

def run_reels(ctx):
    cfg = ctx.job.get("reels", {})
    outdir = ctx.out / "reels"; outdir.mkdir(parents=True, exist_ok=True)
    cal = ctx.out / "reels_plan" / "calendar.json"
    reels = json.loads(cal.read_text()) if cal.exists() else reels_planner.plan(ctx)["reels"]
    lim = cfg.get("limit")
    if lim: reels = reels[: int(lim)]
    done = []
    for r in reels:
        out = outdir / f"{r['id']}.mp4"
        key = f"reel:{r['id']}"
        pr = ctx.man_get(key)
        if pr and pr.get("status") == "ok" and out.exists():
            ctx.log("reel", out, "skip-done"); done.append(r["id"]); continue
        if r["lint"]:
            ctx.log("reel", out, "rules-block", note="; ".join(r["lint"])); continue
        kf = core.prep_image(r["product_image"], ctx.job_dir / "work" / "prep" / f"{Path(r['product_image']).stem}.jpg", 1536)
        shots = [{"keyframe": kf if k == 0 else None, "prompt": s["prompt"], "duration": s["duration"]} for k, s in enumerate(r["shots"])]
        try:
            ch = clip_chain.run_chain(ctx, r["id"], shots, outdir / r["id"], cfg)
            rep, sr = _final(ctx, r["id"], ch["segments"], outdir / r["id"], {"music": cfg.get("music"), "audio": cfg.get("audio", "auto")})
            shutil.copy(rep["output"], out)
            (outdir / f"{r['id']}.txt").write_text(f"{r['hook']}\n\n{r['caption']}\n\n{' '.join(r['hashtags'])}\n", encoding="utf-8")
            ctx.man_set(key, status="ok", out=str(out)); done.append(r["id"])
        except core.BudgetExceeded as e:
            ctx.man_set(key, status="budget_stop", err=str(e)); ctx.log("reel", out, "budget_stop", err=str(e)); break
    return {"done": done}
