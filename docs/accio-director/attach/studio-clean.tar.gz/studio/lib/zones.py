"""zones: vision размечает части товара (bbox + подпись), рисуется карточка «что где» (PNG + SVG) и анимация для сайта (зум/пан по зонам)."""
import json, base64, math, subprocess
from pathlib import Path
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont
from . import core, photo_enhance, rules

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_B = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
ACC = (212, 175, 105)

ZONES_PROMPT = """You annotate product photos for an online catalog. Look at the image and list the distinct VISIBLE parts/zones of the product(s) a customer would want explained
(for example: brand name/logo, front panel, label with composition text, cap/closure, packaging box edge, product itself, texture, secondary box).
Rules: only what is clearly visible; do NOT invent contents; no prices; no technical numbers. If a model/person is present, mark only the product (not the person's face).
%(extra)s
Return ONLY JSON: {"product": "<short name in %(lang)s>", "zones": [{"label": "<=3 words in %(lang)s", "note": "<=9 words in %(lang)s: what this part is / what it shows", "box": [ymin, xmin, ymax, xmax]}]}
Coordinates are integers normalized to 0-1000 (ymin,xmin,ymax,xmax). 3 to 6 zones, boxes tight around the part, no huge overlaps."""

EXTRA_BEAUTY = "Brand rules: do NOT make zones for composition/ingredients/volume/size/dosage text or any technical parameters; call the product only «ZISHÉL Glam»; no mention of prices."

def detect(ctx, img, cfg):
    lang = cfg.get("lang", "Russian")
    prepared = core.prep_image(img, ctx.job_dir / "work" / "prep" / f"{Path(img).stem}.jpg", 1536)
    role = cfg.get("vision_role", "vision")
    res, out, usd, hit = core.call(ctx, ctx.reg.roles[role], {"images": [prepared], "prompt": ZONES_PROMPT % {"lang": lang, "extra": EXTRA_BEAUTY if ctx.rules == "beautyarts" else ""}}, tag=f"zones:{Path(img).stem}")
    j = core.extract_json(out)
    zs = []
    for z in j.get("zones", []):
        try:
            y0, x0, y1, x1 = [max(0, min(1000, int(v))) for v in z["box"]]
            if y1 - y0 < 15 or x1 - x0 < 15: continue
            if (y1 - y0) * (x1 - x0) > 0.7e6 and len(j.get('zones', [])) > 1: continue   # зона «на весь кадр» бесполезна
            zz, fl = rules.clean_zone({"label": str(z["label"])[:40], "note": str(z.get("note", ""))[:90], "box": [y0, x0, y1, x1]}, ctx.rules)
            if fl: ctx.log("zones", img, "rules-flag", note=str(fl)[:120])
            zs.append(zz)
        except Exception:
            continue
    if cfg.get("verify", True) and zs:
        zs, u2 = verify(ctx, prepared, zs, cfg); usd += u2
    prod = rules.fix_product_name(j.get("product", "")) if ctx.rules == "beautyarts" else j.get("product", "")
    return {"product": prod, "zones": zs}, usd

VERIFY_PROMPT = """The image has numbered red rectangles drawn on a product photo. Each rectangle is supposed to tightly cover one named part:
%(list)s
For EACH number, check whether the rectangle really covers that part (look at the actual pixels). If it does not, give a corrected tight box, or ok=false with box=null if the part is not visible.
Return ONLY JSON: [{"id": 1, "ok": true|false, "box": [ymin, xmin, ymax, xmax] or null}] — coordinates normalized 0-1000 like the drawn ones were."""

def verify(ctx, prepared, zs, cfg):
    """Второй проход: рисуем рамки на копии и просим vision проверить/поправить. Возвращает (zones, usd)."""
    im = cv2.imread(str(prepared)); H, W = im.shape[:2]
    for i, z in enumerate(zs):
        y0, x0, y1, x1 = z["box"]
        cv2.rectangle(im, (int(x0 / 1000 * W), int(y0 / 1000 * H)), (int(x1 / 1000 * W), int(y1 / 1000 * H)), (0, 0, 255), max(2, W // 400))
        cv2.putText(im, str(i + 1), (int(x0 / 1000 * W) + 4, int(y0 / 1000 * H) + max(24, W // 40)), cv2.FONT_HERSHEY_SIMPLEX, max(0.8, W / 1400), (0, 0, 255), max(2, W // 500))
    tmp = Path(ctx.job_dir) / "work" / "prep" / (Path(prepared).stem + "_boxes.jpg"); tmp.parent.mkdir(parents=True, exist_ok=True); cv2.imwrite(str(tmp), im)
    lst = "\n".join(f"{i+1}: {z['label']} — {z['note']}" for i, z in enumerate(zs))
    res, out, usd, hit = core.call(ctx, ctx.reg.roles[cfg.get("vision_role", "vision")], {"images": [tmp], "prompt": VERIFY_PROMPT % {"list": lst}}, tag="zones-verify")
    try: fixes = core.extract_json(out)
    except Exception: return zs, usd
    new = []
    byid = {f.get("id"): f for f in fixes if isinstance(f, dict)}
    for i, z in enumerate(zs):
        f = byid.get(i + 1)
        if f is None: new.append(z); continue
        if f.get("ok") is False and not f.get("box"): continue
        if f.get("box") and f.get("ok") is False:
            try:
                y0, x0, y1, x1 = [max(0, min(1000, int(v))) for v in f["box"]]
                if y1 - y0 >= 15 and x1 - x0 >= 15: z = {**z, "box": [y0, x0, y1, x1], "corrected": True}
            except Exception: pass
        new.append(z)
    return new, usd

def _wrap(draw, text, font, width):
    words, lines, cur = text.split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if draw.textlength(t, font=font) <= width: cur = t
        else:
            if cur: lines.append(cur)
            cur = w
    if cur: lines.append(cur)
    return lines

def render_card(img_path, data, out_png, out_svg=None, title=None):
    im = Image.open(img_path).convert("RGB")
    ph = 1300
    pw = int(im.width * ph / im.height)
    pw = min(pw, 1100); ph = int(im.height * pw / im.width)
    im = im.resize((pw, ph), Image.LANCZOS)
    M = 420
    legend_h = 110 + 74 * len(data["zones"])
    Wc, Hc = pw + 2 * M, ph + 150 + legend_h
    card = Image.new("RGB", (Wc, Hc), (14, 14, 16))
    d = ImageDraw.Draw(card)
    f_t = ImageFont.truetype(FONT_B, 40); f_l = ImageFont.truetype(FONT_B, 26); f_n = ImageFont.truetype(FONT, 22); f_num = ImageFont.truetype(FONT_B, 24)
    d.text((M, 40), title or data.get("product", ""), font=f_t, fill=(240, 240, 240))
    ox, oy = M, 110
    card.paste(im, (ox, oy))
    zs = data["zones"]
    svg = [f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{Wc}" height="{Hc}" viewBox="0 0 {Wc} {Hc}" font-family="DejaVu Sans, Arial">',
           f'<rect width="100%" height="100%" fill="#0e0e10"/>', f'<text x="{M}" y="82" font-size="40" font-weight="700" fill="#f0f0f0">{_esc(title or data.get("product",""))}</text>']
    buf = Path(img_path).read_bytes()
    svg.append(f'<image x="{ox}" y="{oy}" width="{pw}" height="{ph}" xlink:href="data:image/jpeg;base64,{base64.b64encode(_jpeg(im)).decode()}"/>')
    # левая/правая колонка выносок, раскладка без перекрытий по y
    left = [i for i, z in enumerate(zs) if (z["box"][1] + z["box"][3]) / 2 < 500]
    right = [i for i in range(len(zs)) if i not in left]
    slots = {}
    for col, ids in (("L", left), ("R", right)):
        ids = sorted(ids, key=lambda i: (zs[i]["box"][0] + zs[i]["box"][2]) / 2)
        last = -999
        for i in ids:
            cy = oy + (zs[i]["box"][0] + zs[i]["box"][2]) / 2000 * ph
            cy = max(cy, last + 128); last = cy
            slots[i] = (col, cy)
    for i, z in enumerate(zs):
        y0, x0, y1, x1 = z["box"]
        bx0, by0, bx1, by1 = ox + x0 / 1000 * pw, oy + y0 / 1000 * ph, ox + x1 / 1000 * pw, oy + y1 / 1000 * ph
        d.rectangle([bx0, by0, bx1, by1], outline=ACC, width=3)
        col, cy = slots[i]
        sx = bx0 if col == "L" else bx1
        sy = (by0 + by1) / 2
        tx = M - 24 if col == "L" else M + pw + 24
        d.line([(sx, sy), (tx, cy)], fill=ACC, width=2)
        r = 17
        d.ellipse([tx - r, cy - r, tx + r, cy + r], fill=ACC)
        d.text((tx, cy), str(i + 1), font=f_num, fill=(10, 10, 10), anchor="mm")
        wmax = M - 70
        ll = _wrap(d, z["label"], f_l, wmax)[:2]; nl = _wrap(d, z["note"], f_n, wmax)[:2]
        if col == "L":
            x = tx - r - 12; anchor = "ra"
        else:
            x = tx + r + 12; anchor = "la"
        yy = cy - 18
        for ln in ll:
            d.text((x, yy), ln, font=f_l, fill=(245, 245, 245), anchor=anchor); yy += 30
        for ln in nl:
            d.text((x, yy + 2), ln, font=f_n, fill=(190, 190, 190), anchor=anchor); yy += 26
        svg.append(f'<rect x="{bx0:.1f}" y="{by0:.1f}" width="{bx1-bx0:.1f}" height="{by1-by0:.1f}" fill="none" stroke="#d4af69" stroke-width="3"/>')
        svg.append(f'<line x1="{sx:.1f}" y1="{sy:.1f}" x2="{tx:.1f}" y2="{cy:.1f}" stroke="#d4af69" stroke-width="2"/><circle cx="{tx:.1f}" cy="{cy:.1f}" r="{r}" fill="#d4af69"/>')
        svg.append(f'<text x="{tx:.1f}" y="{cy+8:.1f}" font-size="24" font-weight="700" text-anchor="middle" fill="#0a0a0a">{i+1}</text>')
        anc = "end" if col == "L" else "start"
        svg.append(f'<text x="{x:.1f}" y="{cy+8:.1f}" font-size="26" font-weight="700" text-anchor="{anc}" fill="#f5f5f5">{_esc(z["label"])}</text>')
    # легенда «что где»
    ly = oy + ph + 40
    d.text((M, ly), "Что где", font=f_l, fill=ACC)
    svg.append(f'<text x="{M}" y="{ly+26}" font-size="26" font-weight="700" fill="#d4af69">Что где</text>')
    for i, z in enumerate(zs):
        yy = ly + 52 + i * 74
        d.ellipse([M, yy, M + 36, yy + 36], fill=ACC); d.text((M + 18, yy + 18), str(i + 1), font=f_num, fill=(10, 10, 10), anchor="mm")
        d.text((M + 54, yy), z["label"], font=f_l, fill=(245, 245, 245))
        d.text((M + 54, yy + 32), z["note"], font=f_n, fill=(190, 190, 190))
        svg.append(f'<circle cx="{M+18}" cy="{yy+18}" r="18" fill="#d4af69"/><text x="{M+18}" y="{yy+27}" font-size="24" font-weight="700" text-anchor="middle" fill="#0a0a0a">{i+1}</text>')
        svg.append(f'<text x="{M+54}" y="{yy+24}" font-size="26" font-weight="700" fill="#f5f5f5">{_esc(z["label"])}</text><text x="{M+54}" y="{yy+54}" font-size="22" fill="#bebebe">{_esc(z["note"])}</text>')
    svg.append("</svg>")
    card.save(out_png)
    if out_svg: Path(out_svg).write_text("\n".join(svg), encoding="utf-8")
    return out_png

def _esc(s): return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def _jpeg(im):
    import io
    b = io.BytesIO(); im.save(b, "JPEG", quality=88); return b.getvalue()

# ---------- анимация для сайта ----------
def _ease(t): return t * t * (3 - 2 * t)

def animate(img_path, data, out_mp4, seconds=None, fps=30, out_w=1080):
    """Медленный зум/пан по зонам с подсветкой и подписью (рендер локально, $0). Лица/текст не искажаются: только кроп/масштаб."""
    src = cv2.imread(str(img_path))
    zs = data["zones"]
    n = len(zs)
    seconds = seconds or min(8.0, max(5.0, 1.6 + 1.3 * n))
    h0, w0 = src.shape[:2]
    out_h = int(round(out_w * h0 / w0 / 2)) * 2
    out_h = min(out_h, 1920)
    big = cv2.resize(src, (out_w * 2, int(out_w * 2 * h0 / w0)), interpolation=cv2.INTER_LANCZOS4)
    BH, BW = big.shape[:2]
    # ключевые кадры камеры: (t, cx, cy, zoom, idx)
    hold0, hold1 = 0.7, 0.6
    per = (seconds - hold0 - hold1) / max(n, 1)
    keys = [(0.0, 0.5, 0.5, 1.0, -1), (hold0, 0.5, 0.5, 1.0, -1)]
    for i, z in enumerate(zs):
        y0, x0, y1, x1 = [v / 1000 for v in z["box"]]
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        zoom = float(np.clip(0.6 / max(x1 - x0, (y1 - y0) * (out_w / out_h)), 1.15, 2.4))
        t0 = hold0 + i * per
        keys += [(t0 + per * 0.45, cx, cy, zoom, i), (t0 + per * 0.88, cx, cy, zoom * 1.04, i)]
    keys.append((seconds, 0.5, 0.5, 1.0, -1))
    f_l = ImageFont.truetype(FONT_B, int(out_w * 0.04)); f_n = ImageFont.truetype(FONT, int(out_w * 0.028))
    chips = []
    for i, z in enumerate(zs):
        ch = Image.new("RGBA", (out_w, int(out_h * 0.17)), (0, 0, 0, 0)); dd = ImageDraw.Draw(ch)
        dd.rounded_rectangle([int(out_w * 0.05), 0, int(out_w * 0.95), ch.height - 8], radius=18, fill=(10, 10, 12, 205))
        dd.ellipse([int(out_w * 0.07), 20, int(out_w * 0.07) + 44, 64], fill=ACC + (255,)); dd.text((int(out_w * 0.07) + 22, 42), str(i + 1), font=f_l, fill=(10, 10, 10), anchor="mm")
        dd.text((int(out_w * 0.07) + 62, 16), z["label"], font=f_l, fill=(245, 245, 245))
        dd.text((int(out_w * 0.07) + 62, 16 + int(out_w * 0.05)), z["note"], font=f_n, fill=(200, 200, 200))
        chips.append(np.array(ch))
    enc = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{out_w}x{out_h}", "-r", str(fps), "-i", "-",
                            "-c:v", "libx264", "-preset", "medium", "-crf", "16", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(out_mp4)], stdin=subprocess.PIPE)
    N = int(round(seconds * fps))
    def cam(t):
        for a, b in zip(keys[:-1], keys[1:]):
            if a[0] <= t <= b[0]:
                u = _ease((t - a[0]) / max(b[0] - a[0], 1e-6))
                return [a[k] + (b[k] - a[k]) * u for k in (1, 2, 3)], (a[4] if u < 0.5 else b[4]) if a[4] != b[4] else a[4], a, b, u
        return [0.5, 0.5, 1.0], -1, keys[-1], keys[-1], 1.0
    for k in range(N):
        t = k / fps
        (cx, cy, z), idx, a, b, u = cam(t)
        cw, ch_ = BW / z, BH / z
        cw = min(cw, BW); ch_ = cw * out_h / out_w
        if ch_ > BH: ch_ = BH; cw = ch_ * out_w / out_h
        x0 = float(np.clip(cx * BW - cw / 2, 0, BW - cw)); y0 = float(np.clip(cy * BH - ch_ / 2, 0, BH - ch_))
        s = out_w / cw
        M = np.float32([[s, 0, -x0 * s], [0, s, -y0 * s]])
        fr = cv2.warpAffine(big, M, (out_w, out_h), flags=cv2.INTER_LANCZOS4)
        # подсветка зоны и чип
        if idx >= 0:
            # прозрачность: нарастает при подлёте, спадает перед отлётом
            alpha = 1.0
            if a[4] == -1 and b[4] == idx: alpha = _ease(max(0, (u - 0.4) / 0.6))
            elif a[4] == idx and b[4] != idx: alpha = 1 - _ease(min(1, u / 0.6))
            y0b, x0b, y1b, x1b = [v / 1000 for v in zs[idx]["box"]]
            p0 = (int((x0b * BW - x0) * s), int((y0b * BH - y0) * s)); p1 = (int((x1b * BW - x0) * s), int((y1b * BH - y0) * s))
            ov = fr.copy(); cv2.rectangle(ov, p0, p1, ACC[::-1], 3, cv2.LINE_AA)
            fr = cv2.addWeighted(ov, alpha, fr, 1 - alpha, 0)
            chip = chips[idx]; yy = out_h - chip.shape[0] - int(out_h * 0.03)
            ca = (chip[:, :, 3:4].astype(np.float32) / 255.0) * alpha
            roi = fr[yy:yy + chip.shape[0], :].astype(np.float32)
            roi = roi * (1 - ca) + chip[:, :, 2::-1].astype(np.float32) * ca
            fr[yy:yy + chip.shape[0], :] = roi.astype(np.uint8)
        enc.stdin.write(np.ascontiguousarray(fr).tobytes())
    enc.stdin.close(); enc.wait()
    return {"seconds": seconds, "size": f"{out_w}x{out_h}", "fps": fps}

def run(ctx):
    cfg = ctx.job.get("zones", {})
    files = photo_enhance.list_images(ctx.job["input_dir"])
    if cfg.get("limit"): files = files[: int(cfg["limit"])]
    outdir = ctx.out / "zones"; outdir.mkdir(parents=True, exist_ok=True)
    from concurrent.futures import ThreadPoolExecutor
    def one(f):
        stem = Path(f).stem
        key = f"zones:{stem}"
        prev = ctx.man_get(key)
        jf = outdir / f"{stem}.zones.json"
        if prev and prev.get("status") == "ok" and jf.exists() and (outdir / f"{stem}_card.png").exists():
            ctx.log("zones", f, "skip-done"); return prev
        try:
            if jf.exists(): data, usd = json.loads(jf.read_text()), 0.0
            else:
                data, usd = detect(ctx, f, cfg); jf.write_text(json.dumps(data, ensure_ascii=False, indent=1))
            if not data["zones"]: raise RuntimeError("зон не найдено")
            prep = core.prep_image(f, ctx.job_dir / "work" / "prep" / f"{stem}.jpg", 2048)
            render_card(prep, data, outdir / f"{stem}_card.png", outdir / f"{stem}_card.svg", title=cfg.get("title"))
            anim = None
            if cfg.get("animate", True):
                anim = animate(prep, data, outdir / f"{stem}_anim.mp4", seconds=cfg.get("anim_seconds"))
            rec = {"status": "ok", "zones": len(data["zones"]), "usd": round(usd, 4), "anim": anim}
            ctx.man_set(key, **rec); ctx.log("zones", f, "ok", usd=round(usd, 4), note=f"{len(data['zones'])} зон")
            return rec
        except core.BudgetExceeded as e:
            ctx.man_set(key, status="budget_stop", err=str(e)); ctx.log("zones", f, "budget_stop", err=str(e)); return {"status": "budget_stop"}
        except Exception as e:
            ctx.man_set(key, status="error", err=repr(e)[:300]); ctx.log("zones", f, "error", err=repr(e)[:200]); return {"status": "error"}
    with ThreadPoolExecutor(ctx.workers) as ex:
        res = list(ex.map(one, files))
    summ = {}
    for r in res: summ[r.get("status")] = summ.get(r.get("status"), 0) + 1
    return {"summary": summ, "outdir": str(outdir)}
