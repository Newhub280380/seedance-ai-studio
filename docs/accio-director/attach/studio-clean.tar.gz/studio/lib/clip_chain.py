"""clip_chain: цепочка сегментов image-to-video. Стартовый кадр сегмента N+1 = РЕАЛЬНЫЙ последний кадр сегмента N (ffmpeg).
Опционально конечный кадр сегмента = следующий ключевой кадр раскадровки (если модель умеет end_image)."""
import json
from pathlib import Path
from . import core, rules

IDENT_LOCK = ("Same people and products throughout: identical faces, hair, outfit, packaging and text, no morphing, no new objects appearing, "
              "single continuous shot without cuts, consistent lighting and colour grade, smooth natural motion.")
NEG = "morphing, distorted face, extra fingers, warped text, flicker, scene cut, jump cut, podium, stand, watermark, blur"

DRIFT_PROMPT = ("Image 1 = START reference. Image 2 = LAST frame of a generated clip. Return ONLY JSON: "
                '{"same_people": true|false|null, "same_product": true|false|null, "same_text": true|false|null, "lighting_consistent": true|false, "score": 0-10, "issues": ""}')


def motion_level(path, n=48):
    """Средняя межкадровая разница (серый, 160px) — «скорость» движения в клипе. Бесплатно (cv2)."""
    import cv2, numpy as np
    cap = cv2.VideoCapture(str(path)); prev = None; ds = []
    while len(ds) < n:
        ok, f = cap.read()
        if not ok: break
        g = cv2.cvtColor(cv2.resize(f, (160, int(160 * f.shape[0] / f.shape[1]))), cv2.COLOR_BGR2GRAY).astype(np.float32)
        if prev is not None: ds.append(float(np.abs(g - prev).mean()))
        prev = g
    return float(np.median(ds)) if ds else 0.0

def run_chain(ctx, name, shots, outdir, cfg=None):
    """shots: [{prompt, duration, keyframe(Path, только у первого обязателен), end_keyframe(Path, опц.)}]
    Возвращает {"segments": [Path...], "lastframes": [...], "join_errors": [...], "usd": x}"""
    cfg = cfg or {}
    outdir = Path(outdir); outdir.mkdir(parents=True, exist_ok=True)
    key_model, m = ctx.reg.role("i2v")
    segs, lasts, usd_total, drift = [], [], 0.0, []
    start = Path(shots[0]["keyframe"])
    motion_log = []
    ref_motion_prev = motion_level(cfg["start_video"]) if cfg.get("start_video") else None
    for i, sh in enumerate(shots):
        seg = outdir / f"{name}_seg{i+1:02d}.mp4"
        lf = outdir / f"{name}_seg{i+1:02d}_last.png"
        mkey = f"chain:{name}:{i}"
        prev = ctx.man_get(mkey)
        if prev and prev.get("status") == "ok" and seg.exists():
            ctx.log("chain", seg, "skip-done")
            if not lf.exists(): core.last_frame(seg, lf)
            segs.append(seg); lasts.append(lf); start = lf
            continue
        prompt = rules.guard_prompt(sh["prompt"].rstrip(". ") + ". " + IDENT_LOCK, ctx.rules)
        end_img = Path(sh["end_keyframe"]) if sh.get("end_keyframe") and m.get("supports_end_image") else None
        dur = int(sh.get("duration", cfg.get("seg_seconds", 4)))
        ref_motion = ref_motion_prev
        rerolls = int(cfg.get("motion_reroll", 0))
        for att in range(rerolls + 1):
            try:
                pr = prompt if att == 0 else prompt + " Keep the camera and subject movement exactly as slow and smooth as in the previous shot."
                res, url, usd, hit = core.call(ctx, key_model, {"image": start, "end_image": end_img, "prompt": pr, "duration": dur,
                                                               "negative": NEG, "seed": 4242 + i + 1000 * att}, tag=f"i2v:{name}:{i}" + (f":re{att}" if att else ""))
            except core.BudgetExceeded as e:
                ctx.man_set(mkey, status="budget_stop", err=str(e)); ctx.log("chain", seg, "budget_stop", err=str(e)); raise
            core.download(url, seg)
            mot = motion_level(seg)
            ratio = (mot / ref_motion) if ref_motion else 1.0
            motion_log.append({"seg": i + 1, "attempt": att, "motion": round(mot, 2), "ref": round(ref_motion or 0, 2), "ratio": round(ratio, 2)})
            usd_total += usd
            if ref_motion and (ratio > float(cfg.get("motion_max_ratio", 2.5)) or ratio < 1 / float(cfg.get("motion_max_ratio", 2.5))):
                ctx.log("chain", seg, "motion_jump", note=f"скорость движения x{ratio:.1f} к предыдущему сегменту" + (" — перегенерация" if att < rerolls else " — оставлено, предупреждение"))
                if att < rerolls: usd = 0.0; continue
            break
        ref_motion_prev = mot
        core.last_frame(seg, lf)
        info = core.probe(seg)
        ctx.man_set(mkey, status="ok", seg=str(seg), usd=usd, info=info)
        ctx.log("chain", seg, "ok", usd=round(usd, 4), note=f"{info.get('width')}x{info.get('height')} {info.get('fps'):.0f}fps {info['duration']:.1f}s audio={info['has_audio']}")
        # контроль дрейфа лица/товара относительно стартового ключевого кадра цепочки
        if cfg.get("drift_check", True):
            try:
                r2, out, u2, _ = core.call(ctx, ctx.reg.roles["vision"], {"images": [Path(shots[0]["keyframe"]), lf], "prompt": DRIFT_PROMPT}, tag="drift")
                usd_total += u2
                j = core.extract_json(out); j["seg"] = i + 1; drift.append(j)
                ctx.log("chain", seg, "drift", qc=j.get("score"), note=j.get("issues", "")[:80])
            except core.BudgetExceeded: raise
            except Exception as e:
                drift.append({"seg": i + 1, "error": repr(e)[:120]})
        segs.append(seg); lasts.append(lf); start = lf
    return {"segments": segs, "lastframes": lasts, "usd": round(usd_total, 4), "drift": drift, "motion": motion_log}

def join_errors(segs):
    """Метрика стыка цепочки: разница между реальным последним кадром сегмента N и первым кадром N+1 (MSE по 0..255, уменьшено)."""
    import cv2, numpy as np
    out = []
    def rd(p, last):
        cap = cv2.VideoCapture(str(p))
        if last:
            n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)); cap.set(cv2.CAP_PROP_POS_FRAMES, max(0, n - 1))
        ok, f = cap.read(); cap.release()
        return cv2.resize(f, (256, 256)).astype(np.float32)
    for a, b in zip(segs[:-1], segs[1:]):
        out.append(float(((rd(a, True) - rd(b, False)) ** 2).mean()))
    return out
