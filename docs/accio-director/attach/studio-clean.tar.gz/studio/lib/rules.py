"""Правила Beautyarts (rules: beautyarts в job.yaml): lint продающих текстов + защита предметки в промптах."""
import re

PRODUCT = "ZISHÉL Glam"
# Фраза-замок для промптов предметки (исключается из lint)
NO_PODIUM_GUARD = "Do not add any podium, pedestal, stand or plinth under or around the product."

_PRICE = re.compile(r"(цен[аыуео]|прайс|стоимост|стоит\b|руб\.?|тенге|\bтг\b|₸|₽|\$|€|\busd\b|\bkzt\b|\bprice\b|\bcost\b|\d\s?(тг|₸|тенге|руб|usd|kzt))", re.I)
_BAN = re.compile(r"(fishbone|распродаж)", re.I)
_TECH = re.compile(r"(\d+([.,]\d+)?\s?(мл|ml|мг|mg|мм|mm|см|cm|кда|kda|%|вт|w\b|гц|hz|ph\b|мкм|µm|g/l|г/л))|(концентрац|вязкост|молекулярн|кросс-?линк|cross-?link|lidocaine|лидокаин|гиалурон)", re.I)
_PODIUM = re.compile(r"(подиум|подставк|пьедестал|podium|pedestal|plinth|\bstand\b)", re.I)
_ROSE = re.compile(r"rose\s+glam|роуз\s+глэм", re.I)
_ZISHEL = re.compile(r"(zish[eéè]l[a-z]*(\s+[A-Za-z]+)?|зишел[а-я]*(\s+[а-яА-Я]+)?)", re.I)

def lint(text, kind="sales"):
    """Возвращает список нарушений. kind: sales (подпись/хук) | prompt (промпт шота)."""
    if not text: return []
    t = text.replace(NO_PODIUM_GUARD, "")
    v = []
    if _BAN.search(t): v.append("запрещённое слово (Fishbone/распродажа)")
    if _PODIUM.search(t) and not re.search(r"(no|without|never|не|без)\s+(any\s+)?(podium|pedestal|stand|plinth|подиум|подставк)", t, re.I):
        v.append("подиум/подставка")
    if kind == "sales":
        if _PRICE.search(t): v.append("цена/валюта")
        if _TECH.search(t): v.append("технические параметры")
    for m in _ZISHEL.finditer(re.sub(r"#\S+", " ", t)):
        if m.group(0).strip() != PRODUCT:
            v.append(f"название продукта: «{m.group(0)}» вместо «{PRODUCT}»")
    return v

def guard_prompt(prompt, rules):
    if rules == "beautyarts" and NO_PODIUM_GUARD not in prompt:
        return prompt.rstrip() + " " + NO_PODIUM_GUARD
    return prompt

def fix_product_name(text):
    if not text: return text
    return _ZISHEL.sub(PRODUCT, _ROSE.sub(PRODUCT, text)) if True else text

def clean_zone(z, rules_mode):
    """Для rules=beautyarts: подписи зон без цен/тех. параметров, название продукта строго «ZISHÉL Glam»."""
    if rules_mode != "beautyarts": return z, []
    flagged = []
    for k in ("label", "note"):
        z[k] = fix_product_name(z.get(k, ""))
        v = lint(z[k], "sales")
        if v:
            flagged.append((k, v)); z[k] = "" if k == "note" else z[k]
    if not z["label"]: z["label"] = "Деталь"
    return z, flagged
