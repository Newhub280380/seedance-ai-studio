"""photo_enhance: пакетное улучшение/замена фона с замком идентичности, QC через vision, возобновление, кэш."""
import json, threading
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from . import core, rules

IMG_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}

LOCK = ("Keep everything identical: every face, identity, skin texture, expression, hair, clothing, pose, body proportions, "
        "composition, products, packaging, labels, text, logos and their exact size and position. Do not add or remove people or objects.")
ENHANCE = ("Professional photo retouch only: balanced exposure and contrast, natural true-to-life colour, clean crisp detail, "
           "gentle noise removal, soft natural light. " + LOCK)
BACKGROUND = ("Replace ONLY the background/scenery with: {bg}. Match the lighting direction, colour temperature, shadows and perspective "
              "of the new setting to the subject so it looks like one real photograph. Everything in the foreground stays identical. " + LOCK)
SCENE = ("Place the same people/product into this new scene: {bg}. Keep their faces and identity exactly the same, same clothing "
         "(add only weather-appropriate outerwear if the scene requires it, keeping colours), natural pose, realistic lighting and shadows. " + LOCK)
STRICT_TAIL = " CRITICAL: previous attempt altered {issues}. Keep faces, products, packaging and every letter of text pixel-faithful."

QC_PROMPT = """You are a strict photo-retouch QA inspector. Image 1 = ORIGINAL. Image 2 = EDITED result. Compare them closely, region by region (faces, product/packaging shape and colour, every line of text and logo, hands, edges).
Be harsh: a change in a face (shape, age, skin tone, expression), packaging colour/finish/shape, or any text becoming fainter, smaller, different or less readable than in the original is a FAIL for that field.
Return ONLY JSON: {"faces_identical": true|false|null (null if no faces), "product_identical": true|false|null (null if no product), "text_intact": true|false|null (null if no text/logo; false if any text/logo changed OR lost contrast/legibility vs original),
"colors_preserved": true|false (overall palette of the subject unchanged%s), "mode_ok": true|false (%s), "artifacts": true|false (extra limbs/fingers, melted shapes, garbled text, seams),
"score": 0-10 (10 = indistinguishable subject), "issues": "list every difference you see, or empty"}"""

def list_images(d):
    d = Path(d)
    return sorted(p for p in d.rglob("*") if p.suffix.lower() in IMG_EXT and not p.name.startswith("."))

def build_variants(cfg, rules_mode):
    vs = []
    if cfg.get("enhance", True):
        vs.append({"name": "enhance", "prompt": ENHANCE, "bg": None})
    for i, bg in enumerate(cfg.get("backgrounds", []) or []):
        vs.append({"name": f"bg{i+1}", "prompt": BACKGROUND.format(bg=bg), "bg": bg})
    for i, sc in enumerate(cfg.get("scenes", []) or []):
        vs.append({"name": f"scene{i+1}", "prompt": SCENE.format(bg=sc), "bg": sc})
    for v in vs:
        v["prompt"] = rules.guard_prompt(v["prompt"], rules_mode)
    return vs

def qc_check(ctx, orig, result, variant, cfg):
    mode = "background/scene changed as requested" if variant["bg"] else "image only retouched, scene NOT changed"
    res, out, usd, hit = core.call(ctx, ctx.reg.roles["vision"], {"images": [Path(orig), Path(result)], "prompt": QC_PROMPT % (", except where the requested background change legitimately alters it" if variant["bg"] else ", i.e. grading/white balance not shifted", mode)}, tag="qc")
    try:
        j = core.extract_json(out)
    except Exception:
        return {"pass": False, "parse_error": True, "raw": out[:200]}, usd
    ok_flags = [j.get(k) for k in ("faces_identical", "product_identical", "text_intact", "colors_preserved")]
    ok = all(f is not False for f in ok_flags) and j.get("mode_ok") is not False and not j.get("artifacts") and float(j.get("score", 0)) >= float(cfg.get("qc_min_score", 8))
    j["pass"] = bool(ok)
    return j, usd

def process_one(ctx, src, variant, cfg, outdir):
    stem = Path(src).stem
    key = f"enhance:{stem}:{variant['name']}"
    out_path = Path(outdir) / f"{stem}__{variant['name']}.jpg"
    prev = ctx.man_get(key)
    if prev and prev.get("status") in ("ok", "qc_flagged") and out_path.exists():
        ctx.log("enhance", src, "skip-done", note=variant["name"])
        return prev
    prepared = core.prep_image(src, ctx.job_dir / "work" / "prep" / f"{stem}.jpg", cfg.get("max_side", 2048))
    max_retries = int(cfg.get("qc_max_retries", 2)) if cfg.get("qc", True) else 0
    total = 0.0
    best = None
    issues = ""
    qc = None
    for attempt in range(max_retries + 1):
        prompt = variant["prompt"] + (STRICT_TAIL.format(issues=issues or "details") if attempt else "")
        try:
            res, url, usd, hit = core.call(ctx, ctx.reg.roles["enhance"], {"image": prepared, "images": [prepared], "prompt": prompt, "seed": 1000 + attempt * 7 + (int(core.sha1(stem)[:6], 16) % 1000)},
                                          tag=f"enhance:{stem}:{variant['name']}")
        except core.BudgetExceeded as e:
            ctx.man_set(key, status="budget_stop", err=str(e)); ctx.log("enhance", src, "budget_stop", err=str(e)); raise
        except Exception as e:
            ctx.man_set(key, status="error", err=repr(e)[:300]); ctx.log("enhance", src, "error", err=repr(e)[:200]); return {"status": "error"}
        total += usd
        cand = Path(outdir) / f"{stem}__{variant['name']}.try{attempt}.jpg"
        core.download(url, cand)
        qc = None
        if cfg.get("qc", True):
            try:
                qc, qusd = qc_check(ctx, prepared, cand, variant, cfg); total += qusd
            except core.BudgetExceeded: raise
            except Exception as e:
                qc = {"pass": False, "error": repr(e)[:200]}
        ctx.log("enhance", src, "attempt", attempt=attempt, qc=(qc or {}).get("pass"), usd=round(usd, 4), note=variant["name"])
        if best is None or (qc and qc.get("pass")) or best[1] is None:
            best = (cand, qc)
        if not cfg.get("qc", True) or (qc and qc.get("pass")):
            best = (cand, qc); break
        issues = (qc or {}).get("issues", "") or "details"
    cand, qc = best
    Path(cand).replace(out_path)
    for t in Path(outdir).glob(f"{stem}__{variant['name']}.try*.jpg"):
        t.unlink()
    status = "ok" if (not cfg.get("qc", True) or (qc and qc.get("pass"))) else "qc_flagged"
    rec = {"status": status, "out": str(out_path), "qc": qc, "usd": round(total, 4), "attempts": attempt + 1}
    ctx.man_set(key, **rec)
    ctx.log("enhance", src, status, usd=round(total, 4), attempt=attempt + 1)
    return rec

def make_review_sheet(pairs, out, cols=3, cell=420):
    from PIL import Image, ImageDraw, ImageFont
    if not pairs: return None
    f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
    rows = len(pairs)
    sheet = Image.new("RGB", (cell * 2 + 30, rows * (cell + 34) + 10), (20, 20, 20))
    d = ImageDraw.Draw(sheet)
    for i, (a, b, label) in enumerate(pairs):
        y = 10 + i * (cell + 34)
        for j, p in enumerate((a, b)):
            im = Image.open(p).convert("RGB"); im.thumbnail((cell, cell))
            sheet.paste(im, (10 + j * (cell + 10), y + 30))
        d.text((10, y + 4), label, fill=(240, 240, 240), font=f)
    sheet.save(out, quality=88)
    return out

def run(ctx):
    cfg = ctx.job.get("enhance", {})
    files = list_images(ctx.job["input_dir"])
    limit = cfg.get("limit")
    if limit: files = files[: int(limit)]
    variants = build_variants(cfg, ctx.rules)
    outdir = ctx.out / "photos"; outdir.mkdir(parents=True, exist_ok=True)
    tasks = [(f, v) for f in files for v in variants]
    ctx.log("enhance", ctx.job["input_dir"], "start", note=f"{len(files)} фото x {len(variants)} вариантов = {len(tasks)} задач, workers={ctx.workers}")
    results = []
    stop = threading.Event()
    def w(t):
        if stop.is_set(): return {"status": "not_run"}
        try: return process_one(ctx, t[0], t[1], cfg, outdir)
        except core.BudgetExceeded:
            stop.set(); return {"status": "budget_stop"}
    with ThreadPoolExecutor(ctx.workers) as ex:
        futs = {ex.submit(w, t): t for t in tasks}
        for fu in as_completed(futs):
            results.append((futs[fu], fu.result()))
    pairs = []
    for (f, v), r in sorted(results, key=lambda x: (str(x[0][0]), x[0][1]["name"])):
        if r.get("status") in ("ok", "qc_flagged"):
            prep = ctx.job_dir / "work" / "prep" / f"{Path(f).stem}.jpg"
            pairs.append((prep, r["out"], f"{Path(f).name} -> {v['name']} [{r['status']}]"))
    sheet = make_review_sheet(pairs, outdir / "_review.jpg")
    summ = {}
    for _, r in results: summ[r.get("status")] = summ.get(r.get("status"), 0) + 1
    ctx.log("enhance", ctx.job["input_dir"], "done", note=json.dumps(summ))
    return {"summary": summ, "review": str(sheet) if sheet else None, "outdir": str(outdir)}
