"""Предварительная смета по ценам из models.yaml (источник цен: страницы моделей fal.ai, 2026-10-24)."""
import datetime
from pathlib import Path
from . import core, photo_enhance

VISION_CALL = 0.0015      # реальная цена flash-vision на 1–2 картинки по usage.cost ответов (замерено на живом прогоне)
ZONES_CALL = 0.0025

def n_files(ctx, key="input_dir", default=0):
    d = ctx.job.get(key)
    if d and Path(d).exists():
        n = len(photo_enhance.list_images(d))
        if n: return n
    return int(ctx.job.get("assume_files", default))

def line(items, stage, what, qty, unit, usd):
    items.append({"stage": stage, "what": what, "qty": qty, "unit": unit, "usd": round(usd, 3)})

def estimate_job(ctx, today=None):
    j, reg, items = ctx.job, ctx.reg, []
    retry = float(j.get("assume_qc_retry_factor", 1.25))
    reroll = float(j.get("assume_video_reroll", 1.0))
    N = n_files(ctx)
    ek, em = reg.role("enhance")
    if "enhance" in j:
        e = j["enhance"]
        nv = (1 if e.get("enhance", True) else 0) + len(e.get("backgrounds", []) or []) + len(e.get("scenes", []) or [])
        cnt = min(N, int(e["limit"])) if e.get("limit") else N
        calls = cnt * nv
        qc = e.get("qc", True)
        line(items, "enhance", f"правка фото ({ek}) x{retry} перегенерации", round(calls * (retry if qc else 1), 1), core.unit_price(em, today=today), calls * (retry if qc else 1) * core.unit_price(em, today=today))
        if qc:
            vk, vm = reg.role("vision")
            line(items, "enhance", f"QC vision ({vk})", round(calls * retry, 1), VISION_CALL, calls * retry * VISION_CALL)
    if "zones" in j:
        z = j["zones"]; cnt = min(N, int(z["limit"])) if z.get("limit") else N
        line(items, "zones", "разметка зон (vision) + карточка + анимация (локально)", cnt, ZONES_CALL, cnt * ZONES_CALL)
    ik, im = reg.role("i2v")
    def seg_cost(sec, res=None):
        return core.unit_price(im, duration=sec, today=today) * reroll
    drift = VISION_CALL
    if "hero_videos" in j:
        h = j["hero_videos"]; segs = int(h["count"]) * max(1, int(h["seconds"]) // int(h.get("seg_seconds", 5)))
        line(items, "hero", f"сегменты видео ({ik}) {h['seg_seconds']}с x{reroll}", segs, seg_cost(h.get("seg_seconds", 5)), segs * seg_cost(h.get("seg_seconds", 5)))
        line(items, "hero", "контроль дрейфа (vision)", segs, drift, segs * drift)
        up = h.get("stitch", {}).get("upscale") or j.get("stitch", {}).get("upscale")
        if up == "fal":
            uk, um = reg.role("upscale_video")
            tw, th = map(int, (h.get("stitch", {}).get("upscale_target") or j.get("stitch", {}).get("upscale_target", "3840x2160")).split("x"))
            secs = int(h["count"]) * int(h["seconds"])
            line(items, "hero", f"апскейл {tw}x{th} ({uk})", secs, tw * th / 1e6 * 24 * 0.001, secs * tw * th / 1e6 * 24 * 0.001)
    if "minis" in j:
        m = j["minis"]; c = int(m.get("count", 20)); sg = int(m.get("segments", 2)); sc = int(m.get("seg_seconds", 4))
        line(items, "minis", f"сцена-кадр ({ek}) x{retry}", c, core.unit_price(em, today=today) * retry, c * core.unit_price(em, today=today) * retry)
        line(items, "minis", "QC кадра (vision)", c, VISION_CALL * retry, c * VISION_CALL * retry)
        line(items, "minis", f"сегменты видео ({ik}) {sc}с x{reroll}", c * sg, seg_cost(sc), c * sg * seg_cost(sc))
        line(items, "minis", "контроль дрейфа (vision)", c * sg, drift, c * sg * drift)
    if "reels" in j:
        r = j["reels"]; c = int(r.get("limit") or r.get("count", 30)); sg = int(r.get("shots_per_reel", 4)); sc = int(r.get("seg_seconds", 4))
        line(items, "reels", f"сегменты видео ({ik}) {sc}с x{reroll}", c * sg, seg_cost(sc), c * sg * seg_cost(sc))
        line(items, "reels", "контроль дрейфа (vision)", c * sg, drift, c * sg * drift)
        if r.get("planner") == "llm":
            line(items, "reels", "LLM календарь", 30, 0.004, 30 * 0.004)
    if "continue" in j:
        c = j["continue"]; sg = int(c.get("segments", 3)); sc = int(c.get("seg_seconds", 3))
        line(items, "continue", f"сегменты видео ({ik}) {sc}с", sg, seg_cost(sc), sg * seg_cost(sc))
        line(items, "continue", "контроль дрейфа (vision)", sg, drift, sg * drift)
        if j.get("stitch", {}).get("upscale") == "fal":
            line(items, "continue", "апскейл fal (оценка)", 1, 0.12, 0.12)
    return items

def print_estimate(ctx):
    items = estimate_job(ctx)
    tot = sum(i["usd"] for i in items)
    print(f"\nСМЕТА job «{ctx.name}» (цены fal на {datetime.date.today()}; потолок job ${ctx.budget.cap:.2f}; глобальный ${ctx.budget.gcap})")
    print(f"{'этап':9} {'что':58} {'кол-во':>8} {'$/ед':>8} {'$':>9}")
    for i in items:
        print(f"{i['stage']:9} {i['what'][:58]:58} {i['qty']:>8} {i['unit']:>8.4f} {i['usd']:>9.2f}")
    print(f"{'ИТОГО':9} {'':58} {'':>8} {'':>8} {tot:>9.2f}")
    if ctx.budget.cap <= 0: print("budget_usd=0 -> режим dry-run: платные вызовы запрещены.")
    elif tot > ctx.budget.cap: print(f"!! смета ${tot:.2f} > потолка ${ctx.budget.cap:.2f}: прогон остановится при достижении потолка.")
    return tot
