"""Ядро: реестр моделей, бюджет/леджер, вызов fal с кэшем и ретраями, лог, манифест."""
import os, sys, json, time, hashlib, threading, shutil, urllib.request, datetime, subprocess
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parent.parent
TZ_LABEL = "Asia/Qyzylorda"
PROMO_END = datetime.date(2026, 10, 31)   # промо-цены MiniMax H3 Max на fal действуют до этой даты включительно

def now():
    return time.strftime("%Y-%m-%d %H:%M:%S")

def load_yaml(p):
    with open(p, encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def sha1(*parts):
    h = hashlib.sha1()
    for p in parts:
        if isinstance(p, (bytes, bytearray)):
            h.update(p)
        else:
            h.update(json.dumps(p, sort_keys=True, ensure_ascii=False, default=str).encode())
    return h.hexdigest()

def file_sha1(path, n=1 << 20):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        while True:
            b = f.read(n)
            if not b: break
            h.update(b)
    return h.hexdigest()

# ---------------- реестр ----------------
class Registry:
    def __init__(self, overrides=None):
        d = load_yaml(ROOT / "models.yaml")
        self.models = d["models"]
        self.roles = dict(d["roles"])
        self.roles.update(overrides or {})

    def role(self, role):
        key = self.roles[role]
        return key, self.models[key]

    def get(self, key):
        return key, self.models[key]

def dget(d, path):
    cur = d
    for p in path.split("."):
        if isinstance(cur, list): cur = cur[int(p)]
        else: cur = cur[p]
    return cur

# ---------------- цены ----------------
def unit_price(model, duration=None, resolution=None, n=1, megapixel_frames=None, today=None):
    """Оценка цены одного вызова в $. today — для промо-цен."""
    today = today or datetime.date.today()
    pr = model["price"]
    if "per_image" in pr:
        return pr["per_image"] * n
    if "per_call" in pr:
        return pr["per_call"] * n
    if "per_megapixel_frame" in pr:
        return pr["per_megapixel_frame"] * (megapixel_frames or 0)
    if "first5" in pr:
        d = max(duration or 5, 5)
        return pr["first5"] + pr["per_extra_second"] * (d - 5)
    if "per_second" in pr:
        ps = pr["per_second"]
        if isinstance(ps, dict):
            res = resolution or model.get("fixed", {}).get(pr.get("resolution_arg", "resolution"))
            if today > PROMO_END and "per_second_after_promo" in pr:
                ps = pr["per_second_after_promo"]
            ps = ps[res]
        d = (duration or 5) + pr.get("extra_seconds", 0)
        return ps * d
    raise ValueError("нет схемы цены")

# ---------------- бюджет ----------------
class BudgetExceeded(RuntimeError):
    pass

class Budget:
    """Жёсткий потолок. cap по job.yaml (по умолчанию 0 = только dry-run) + глобальный потолок studio/config.yaml."""
    def __init__(self, job_dir, cap_usd, global_cap_usd, go):
        self.lock = threading.Lock()
        self.job_dir = Path(job_dir)
        self.path = self.job_dir / "ledger.json"
        self.gpath = ROOT / "ledger_global.json"
        self.cap = float(cap_usd or 0)
        self.gcap = float(global_cap_usd) if global_cap_usd is not None else None
        self.go = bool(go)
        self.pending = 0.0      # зарезервировано под вызовы «в полёте» (параллельные воркеры)
        self.entries = self._load(self.path)
        self.gentries = self._load(self.gpath)

    @staticmethod
    def _load(p):
        if Path(p).exists():
            return json.loads(Path(p).read_text())
        return []

    def spent(self):
        return sum(e["usd"] for e in self.entries)

    def gspent(self):
        return sum(e["usd"] for e in self.gentries)

    def release(self, est):
        with self.lock:
            self.pending = max(0.0, self.pending - est)

    def check(self, est, tag="", reserve=False):
        """Проверка ПЕРЕД платным вызовом (est — оценка)."""
        with self.lock:
            if not self.go:
                raise BudgetExceeded("dry-run: платные вызовы запрещены без --go")
            if self.cap <= 0:
                raise BudgetExceeded("budget_usd=0 в job.yaml: платные вызовы запрещены")
            if self.spent() + self.pending + est > self.cap + 1e-9:
                raise BudgetExceeded(f"потолок job ${self.cap:.2f}: потрачено ${self.spent():.3f} (+в полёте ${self.pending:.3f}) + {tag} ${est:.3f} > потолка")
            if self.gcap is not None and self.gspent() + self.pending + est > self.gcap + 1e-9:
                raise BudgetExceeded(f"ГЛОБАЛЬНЫЙ потолок ${self.gcap:.2f}: потрачено ${self.gspent():.3f} + {tag} ${est:.3f} > потолка")
            if reserve:
                self.pending += est

    def record(self, usd, tag, endpoint, est=None, info=None):
        e = {"ts": now(), "tag": tag, "endpoint": endpoint, "usd": round(float(usd), 5), "est": est, "info": info or {}}
        with self.lock:
            self.entries.append(e); self.gentries.append(e)
            self.job_dir.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps(self.entries, ensure_ascii=False, indent=1))
            self.gpath.write_text(json.dumps(self.gentries, ensure_ascii=False, indent=1))

    def reserve_and_record(self, est, tag, endpoint, info=None):
        self.check(est, tag)
        self.record(est, tag, endpoint, est, info)

    def report(self):
        by = {}
        for e in self.entries:
            k = e["endpoint"]
            by.setdefault(k, [0, 0.0])
            by[k][0] += 1; by[k][1] += e["usd"]
        return {"cap_usd": self.cap, "global_cap_usd": self.gcap, "spent_usd": round(self.spent(), 4),
                "global_spent_usd": round(self.gspent(), 4), "by_endpoint": {k: {"calls": v[0], "usd": round(v[1], 4)} for k, v in by.items()}}

# ---------------- контекст job ----------------
class Ctx:
    def __init__(self, job_path, go=False, workers=None):
        self.job_path = Path(job_path)
        self.job_dir = self.job_path.parent
        self.job = load_yaml(self.job_path)
        self.cfg = load_yaml(ROOT / "config.yaml") if (ROOT / "config.yaml").exists() else {}
        self.name = self.job.get("name", self.job_dir.name)
        self.go = go
        self.reg = Registry(self.job.get("models"))
        out = self.job.get("out_dir")
        self.out = Path(out) if out else self.job_dir / "out"
        if not self.out.is_absolute():
            self.out = (ROOT / self.out)
        self.out.mkdir(parents=True, exist_ok=True)
        self.cache = ROOT / "cache"
        self.cache.mkdir(exist_ok=True)
        (self.job_dir / "logs").mkdir(exist_ok=True)
        self.workers = workers or int(self.job.get("workers", 4))
        self.budget = Budget(self.job_dir, self.job.get("budget_usd", 0), self.cfg.get("global_cap_usd"), go)
        self.rules = self.job.get("rules", "none")
        self._log_lock = threading.Lock()
        self._man_lock = threading.Lock()
        self.manifest_path = self.job_dir / "manifest.jsonl"
        self.up_lock = threading.Lock()

    # лог по каждому файлу/шагу
    def log(self, stage, item, status, **kw):
        rec = {"ts": now(), "tz": TZ_LABEL, "stage": stage, "item": str(item), "status": status}
        rec.update(kw)
        line = json.dumps(rec, ensure_ascii=False, default=str)
        with self._log_lock:
            with open(self.job_dir / "logs" / "run.jsonl", "a", encoding="utf-8") as f:
                f.write(line + "\n")
        print(f"[{rec['ts']}] {stage} {Path(str(item)).name} {status} " + " ".join(f"{k}={v}" for k, v in kw.items() if k in ("usd", "attempt", "qc", "note", "err")), flush=True)

    def man_set(self, key, **kw):
        with self._man_lock:
            with open(self.manifest_path, "a", encoding="utf-8") as f:
                f.write(json.dumps({"key": key, "ts": now(), **kw}, ensure_ascii=False, default=str) + "\n")

    def man_get(self, key):
        last = None
        if self.manifest_path.exists():
            for line in self.manifest_path.read_text(encoding="utf-8").splitlines():
                try: r = json.loads(line)
                except Exception: continue
                if r.get("key") == key: last = r
        return last

    def man_load(self):
        d = {}
        if self.manifest_path.exists():
            for line in self.manifest_path.read_text(encoding="utf-8").splitlines():
                try: r = json.loads(line)
                except Exception: continue
                d[r["key"]] = r
        return d

# ---------------- fal ----------------
_fal = None
def fal():
    global _fal
    if _fal is None:
        import fal_client
        _fal = fal_client
    return _fal

def upload(ctx, path):
    """Загрузка файла в fal storage с кэшем по sha1 файла."""
    path = Path(path)
    h = file_sha1(path)
    cp = ctx.cache / "uploads.json"
    with ctx.up_lock:
        d = json.loads(cp.read_text()) if cp.exists() else {}
        if h in d and time.time() - d[h]["t"] < 20 * 3600:
            return d[h]["url"]
    url = fal().upload_file(str(path))
    with ctx.up_lock:
        d = json.loads(cp.read_text()) if cp.exists() else {}
        d[h] = {"url": url, "t": time.time()}
        cp.write_text(json.dumps(d))
    return url

class FatalFal(RuntimeError):
    pass

def download(url, dest):
    dest = Path(dest); dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    last = None
    for i in range(3):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "studio/1.0"})
            with urllib.request.urlopen(req, timeout=180) as r, open(tmp, "wb") as f:
                shutil.copyfileobj(r, f)
            tmp.replace(dest); return dest
        except Exception as e:
            last = e; time.sleep(2 * (i + 1))
    raise RuntimeError(f"download failed: {last!r}")

def call(ctx, model_key, inputs, tag, n=1, duration=None, resolution=None, mp_frames=None, est=None, extra=None, use_cache=True):
    """Универсальный вызов инструмента по ключу из реестра.
    inputs: dict логических аргументов (image/images/prompt/end_image/duration/video/...). Путь к файлу (Path) загружается автоматически.
    Возвращает (result_dict, out_value, usd)."""
    key, m = ctx.reg.get(model_key)
    args = dict(m.get("fixed", {}))
    if extra: args.update(extra)
    cache_parts = {"model": key, "fixed": args}
    for logical, val in inputs.items():
        if val is None: continue
        target = m["args"].get(logical)
        if target is None:
            continue   # модель не поддерживает этот параметр (напр. end_image) — молча пропускаем
        def conv(v):
            if isinstance(v, Path):
                return ("FILE", file_sha1(v), v)
            return ("VAL", v, v)
        if isinstance(val, list):
            conv_l = [conv(v) for v in val]
            cache_parts[logical] = [(c[0], c[1]) for c in conv_l]
            args[target] = ("LIST", conv_l)
        else:
            c = conv(val)
            cache_parts[logical] = (c[0], c[1])
            args[target] = c
    if "duration" in inputs and inputs["duration"] is not None and "duration" in m["args"]:
        d = inputs["duration"]
        d = max(int(d), m.get("min_duration", 1))
        duration = d
        args[m["args"]["duration"]] = d if m.get("duration_type") == "int" else str(d)
        cache_parts["duration"] = d
    ckey = sha1(cache_parts)
    cfile = ctx.cache / f"{ckey}.json"
    if use_cache and cfile.exists():
        r = json.loads(cfile.read_text())
        return r["result"], dget(r["result"], m["out"]), 0.0, True
    if est is None:
        est = unit_price(m, duration=duration, resolution=resolution or args.get("resolution"), n=n, megapixel_frames=mp_frames)
    ctx.budget.check(est, tag, reserve=True)   # <-- жёсткая проверка + резерв до траты
    try:
        # финальные аргументы (загрузка файлов)
        final = {}
        for k, v in args.items():
            if isinstance(v, tuple) and v and v[0] == "FILE":
                final[k] = upload(ctx, v[2])
            elif isinstance(v, tuple) and v and v[0] == "VAL":
                final[k] = v[2]
            elif isinstance(v, tuple) and v and v[0] == "LIST":
                final[k] = [upload(ctx, c[2]) if c[0] == "FILE" else c[2] for c in v[1]]
            else:
                final[k] = v
        last = None
        for attempt in range(3):
            try:
                t0 = time.time()
                res = fal().subscribe(m["endpoint"], arguments=final)
                dt = time.time() - t0
                break
            except Exception as e:
                last = e
                s = repr(e).lower()
                if any(w in s for w in ("422", "validation", "content_policy", "safety", "nsfw", "401", "403", "unauthorized", "forbidden", "balance", "exhausted", "insufficient")):
                    raise FatalFal(f"{m['endpoint']}: {repr(e)[:400]}")
                time.sleep(3 * (attempt + 1))
        else:
            raise RuntimeError(f"{m['endpoint']} не отработал за 3 попытки: {repr(last)[:300]}")
        usd = est
        pr = m["price"]
        if "actual_from" in pr:
            try: usd = float(dget(res, pr["actual_from"]))
            except Exception: pass
        ctx.budget.record(usd, tag, m["endpoint"], est, {"sec": round(dt, 1)})
    finally:
        ctx.budget.release(est)
    cfile.write_text(json.dumps({"result": res, "usd": usd, "ts": now()}, ensure_ascii=False))
    return res, dget(res, m["out"]), usd, False

# ---------------- ffmpeg ----------------
def sh(cmd, check=True):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"cmd failed: {' '.join(map(str, cmd))[:300]}\n{r.stderr[-800:]}")
    return r

def probe(path):
    r = sh(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)])
    j = json.loads(r.stdout)
    v = next((s for s in j["streams"] if s["codec_type"] == "video"), None)
    a = next((s for s in j["streams"] if s["codec_type"] == "audio"), None)
    info = {"duration": float(j["format"].get("duration", 0))}
    if v:
        num, den = v["r_frame_rate"].split("/")
        info.update(width=v["width"], height=v["height"], fps=float(num) / float(den) if float(den) else 0,
                    nb_frames=int(v.get("nb_frames") or 0))
    info["has_audio"] = a is not None
    if a: info["sample_rate"] = int(a.get("sample_rate", 0))
    return info

def last_frame(video, out_png):
    """Настоящий последний кадр видео (ffmpeg перезаписывает файл каждым кадром последней секунды)."""
    out_png = Path(out_png); out_png.parent.mkdir(parents=True, exist_ok=True)
    sh(["ffmpeg", "-y", "-v", "error", "-sseof", "-1", "-i", str(video), "-update", "1", "-q:v", "1", "-frames:v", "100000", str(out_png)])
    return out_png

def first_frame(video, out_png):
    sh(["ffmpeg", "-y", "-v", "error", "-i", str(video), "-frames:v", "1", str(out_png)])
    return out_png

def extract_json(text):
    """Достать JSON из ответа LLM (в т.ч. в ```json ... ```)."""
    import re
    t = text.strip()
    m = re.search(r"```(?:json)?\s*(.*?)```", t, re.S)
    if m: t = m.group(1).strip()
    try:
        return json.loads(t)
    except Exception:
        pass
    for o, c in (("{", "}"), ("[", "]")):
        i, j = t.find(o), t.rfind(c)
        if i != -1 and j > i:
            try: return json.loads(t[i:j + 1])
            except Exception: continue
    raise ValueError("не удалось разобрать JSON из ответа: " + t[:200])

def prep_image(src, dst, max_side=2048, quality=95):
    """Подготовка входного фото: EXIF-поворот, RGB, ограничение стороны. Кэшируется по имени dst."""
    from PIL import Image, ImageOps
    dst = Path(dst)
    if dst.exists(): return dst
    dst.parent.mkdir(parents=True, exist_ok=True)
    im = Image.open(src); im = ImageOps.exif_transpose(im).convert("RGB")
    w, h = im.size
    s = max_side / max(w, h)
    if s < 1: im = im.resize((int(w * s), int(h * s)), Image.LANCZOS)
    im.save(dst, "JPEG", quality=quality)
    return dst
