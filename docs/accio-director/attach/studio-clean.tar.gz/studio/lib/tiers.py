"""Сметы по тарифам (Eco / Standard / Premium) для заказов 1 и 2. Цены — из models.yaml (fal.ai, проверены 2026-10-24).
Запуск: studio.py tiers  ->  ESTIMATES.md"""
import datetime, types
from . import core, estimate

PROMO_END = core.PROMO_END if hasattr(core, "PROMO_END") else datetime.date(2026, 10, 31)

TIERS = {
    "Eco":      dict(models={"enhance": "kontext", "i2v": "minimax_h3"},        qc_retry=1.6, reroll=1.3, upscale="none"),
    "Standard": dict(models={"enhance": "nano_banana_2", "i2v": "kling_v3"},     qc_retry=1.4, reroll=1.3, upscale="none"),
    "Premium":  dict(models={"enhance": "nano_banana_pro", "i2v": "kling_v3"},   qc_retry=1.25, reroll=1.3, upscale="fal"),
}

def order1(t):
    return {"assume_files": 50, "models": t["models"], "assume_qc_retry_factor": t["qc_retry"], "assume_video_reroll": t["reroll"],
            "enhance": {"enhance": True, "backgrounds": ["bg-1", "bg-2"], "qc": True},
            "hero_videos": {"count": 3, "seconds": 45, "seg_seconds": 5, "stitch": {"upscale": t["upscale"], "upscale_target": "1920x1080"}},
            "minis": {"count": 20, "segments": 2, "seg_seconds": 4}}

def order2(t, motion_products=0):
    j = {"assume_files": 1000, "models": t["models"], "assume_qc_retry_factor": t["qc_retry"], "assume_video_reroll": t["reroll"],
         "enhance": {"enhance": True, "backgrounds": [], "qc": True},
         "zones": {},
         "reels": {"count": 30, "shots_per_reel": 4, "seg_seconds": 4, "planner": "llm"}}
    return j

def calc(job, today):
    ctx = types.SimpleNamespace(job=job, reg=core.Registry(job.get("models")))
    items = estimate.estimate_job(ctx, today=today)
    return items, round(sum(i["usd"] for i in items), 2)

def motion_per_product(models, today, seconds=5):
    reg = core.Registry(models); _, m = reg.role("i2v")
    return round(core.unit_price(m, duration=seconds, today=today) * 1.3, 3)

def write_markdown(path):
    promo = PROMO_END - datetime.timedelta(days=1)
    after = PROMO_END + datetime.timedelta(days=1)
    L = ["# Сметы (оценка, $) — fal.ai, цены проверены 2026-10-24", "",
         "Допущения: QC-перегенерации фото ×1.25–1.6 (на живом тесте строгий QC с первого раза пропустил 3 из 6 правок «тёмная глянцевая упаковка + светлый фон»), "
         "пересъёмка видео-сегментов ×1.3, видео — сегменты по 5 с (заказ 1) / 4 с (мини, рилсы), итог склеивается локально ($0). "
         "minimax H3: промо-цена до 2026-10-31, после — дороже (в таблице обе колонки). Реальный факт: сегмент H3 3 с = $0.192 (3+0.7 с биллинга × $0.052).", "",
         "Тарифы: **Eco** = kontext + minimax H3 768p, **Standard** = nano-banana-2 + Kling v3 (эндпоинты Standard/Premium не прогонялись вживую — проверить 1 вызовом до большого запуска), "
         "**Premium** = nano-banana-pro + Kling v3 + AI-апскейл seedvr 1080p.", ""]
    for title, fn in (("Заказ 1: 50 фото (правка + 2 фона = 150 правок) + 3 видео по ~45 с + 20 мини-клипов (кадр-сцена + 2×4 с)", order1),
                      ("Заказ 2: 1000 фото (правка) + 1000 карточек зон (локальная анимация $0) + 30 рилсов (4 шота × 4 с)", order2)):
        L += [f"## {title}", "", "| Тариф | Итого, промо (до 31.10) | Итого, после промо | Разбивка (промо) |", "|---|---|---|---|"]
        for name, t in TIERS.items():
            it, tot = calc(fn(t), promo)
            _, tot2 = calc(fn(t), after)
            br = "; ".join(f"{i['stage']}: ${i['usd']:.0f}" if i['usd'] >= 1 else f"{i['stage']}: ${i['usd']:.2f}" for i in _agg(it))
            L.append(f"| {name} | **${tot:.0f}** | ${tot2:.0f} | {br} |")
        L.append("")
    L += ["## Опция для заказа 2: AI-движение (3D-подобная анимация) на карточку товара, 5 с",
          "Бесплатно по умолчанию — локальная анимация зон (zoom/pan + подсветка + подпись). AI-видео на товар — за деньги:", ""]
    for name, t in TIERS.items():
        a, b = motion_per_product(t["models"], promo), motion_per_product(t["models"], after)
        L.append(f"- {name}: ${a} за товар (после промо ${b}); на 100 товаров ≈ ${a*100:.0f}; на все 1000 ≈ ${a*1000:.0f}")
    L += ["", "Полный пересчёт под реальный каталог: `studio.py estimate jobs/<имя>` (читает job.yaml и models.yaml).", ""]
    from pathlib import Path
    Path(path).write_text("\n".join(L), encoding="utf-8")

def _agg(items):
    agg = {}
    for i in items:
        agg.setdefault(i["stage"], {"stage": i["stage"], "usd": 0})["usd"] += i["usd"]
    return list(agg.values())
