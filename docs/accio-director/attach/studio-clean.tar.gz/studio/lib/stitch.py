"""stitch: бесшовная склейка. Нормализация fps/размера, матчинг цвета на стыках (Lab), подрезка стыка по движению
(поиск пары кадров с минимальной разницей и совпадающей скоростью), кросс-диссолв только если стык не «чистый»,
deflicker, звук (кроссфейд на сэмплах / музыка / тишина), loudnorm, апскейл, отчёт по швам."""
import json, math, subprocess, sys
from pathlib import Path
import numpy as np, cv2
from . import core

DEF = dict(width=None, height=None, fps=None, max_long_side=1920, color_match=True, cut_search_s=0.6,
           hard_mse_floor=12.0, xfade_max_s=0.34, deflicker=True, crf=14, preset="medium", lufs=-16.0,
           audio="auto", music=None, voice=None, music_gain_db=-12.0, upscale="none", upscale_target="3840x2160",
           small_w=192, de_shift_min=2.0)

# ---------- чтение ----------
def _vf(W, H, fps):
    return f"fps={fps},scale={W}:{H}:force_original_aspect_ratio=increase:flags=lanczos,crop={W}:{H}"

def read_frames(path, W, H, fps):
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-i", str(path), "-vf", _vf(W, H, fps), "-f", "rawvideo", "-pix_fmt", "bgr24", "-"],
                         stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    n = W * H * 3
    try:
        while True:
            b = p.stdout.read(n)
            if len(b) < n: break
            yield np.frombuffer(b, np.uint8).reshape(H, W, 3)
    finally:
        p.stdout.close(); p.wait()

def read_all_small(path, W, H, fps, sw):
    sh = max(2, int(round(sw * H / W / 2)) * 2)
    fr = [cv2.resize(f, (sw, sh), interpolation=cv2.INTER_AREA) for f in read_frames(path, W, H, fps)]
    return np.stack(fr)

# ---------- цвет ----------
def lab_stats(frames):
    lab = np.stack([cv2.cvtColor(f.astype(np.float32) / 255.0, cv2.COLOR_BGR2LAB) for f in frames]).reshape(-1, 3)
    return lab.mean(0), lab.std(0) + 1e-3

def make_T(src_frames, tgt_frames):
    ms, ss = lab_stats(src_frames); mt, st = lab_stats(tgt_frames)
    s = np.clip(st / ss, 0.85, 1.18)
    s[1:] = np.clip(s[1:], 0.7, 1.4)
    shift = mt - ms * s
    return {"scale": s.astype(np.float32), "shift": shift.astype(np.float32)}

def apply_T(frame, T):
    if T is None: return frame
    lab = cv2.cvtColor(frame.astype(np.float32) / 255.0, cv2.COLOR_BGR2LAB)
    lab = lab * T["scale"] + T["shift"]
    out = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
    return np.clip(out * 255.0 + 0.5, 0, 255).astype(np.uint8)

def delta_lab(fa, fb):
    la = cv2.cvtColor(fa.astype(np.float32) / 255.0, cv2.COLOR_BGR2LAB); lb = cv2.cvtColor(fb.astype(np.float32) / 255.0, cv2.COLOR_BGR2LAB)
    return float(np.abs(la - lb).mean(axis=(0, 1)).sum())

def motion_series(S):
    g = np.stack([cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).astype(np.float32) for f in S])
    m = np.zeros(len(S), np.float32)
    m[1:] = np.abs(g[1:] - g[:-1]).mean(axis=(1, 2))
    if len(m) > 1: m[0] = m[1]
    return m

# ---------- подбор стыка ----------
def find_cut(SA, SB, mA, mB, K, fps):
    """a — индекс последнего кадра A, b — индекс кадра B, после которого идёт продолжение (выводим B[b+1:]).
    Минимизируем: MSE(A[a],B[b]) + разница скоростей + штраф за съеденное время."""
    nA, nB = len(SA), len(SB)
    best = None
    for a in range(max(nA - 1 - K, nA // 2), nA):
        for b in range(0, min(K, nB // 2) + 1):
            mse = float(((SA[a].astype(np.float32) - SB[b].astype(np.float32)) ** 2).mean())
            dm = abs(float(mA[a]) - float(mB[min(b + 1, nB - 1)]))
            trim = (nA - 1 - a) + b
            sc = mse + 4.0 * dm + 0.8 * trim
            if best is None or sc < best["score"]:
                best = dict(a=a, b=b, mse=mse, dm=dm, trim=trim, score=sc)
    return best

# ---------- аудио ----------
SR = 48000
def read_audio(path):
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-vn", "-ac", "2", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True)
    if r.returncode != 0 or len(r.stdout) < 8: return None
    return np.frombuffer(r.stdout, np.float32).reshape(-1, 2)

def rms(x):
    x = x[np.abs(x).max(axis=1) > 1e-4] if x is not None and len(x) else x
    return float(np.sqrt((x ** 2).mean())) if x is not None and len(x) else 0.0

def build_audio_from_segments(segs_audio, plan, fps, total_frames):
    """segs_audio: список np.array|None. plan: [{s,e,o,n_in,n_out,hard_in,hard_out}]. Возвращает np.array (N,2)."""
    total = int(round(total_frames / fps * SR))
    out = np.zeros((total + SR, 2), np.float32)
    rms_list = [rms(a) for a in segs_audio if a is not None]
    ref = float(np.median([r for r in rms_list if r > 0])) if any(r > 0 for r in rms_list) else 0.0
    HW = int(0.015 * SR)
    for i, (au, p) in enumerate(zip(segs_audio, plan)):
        if au is None: continue
        g = 1.0
        r = rms(au)
        if ref > 0 and r > 0: g = float(np.clip(ref / r, 0.5, 2.0))
        t0_out = int(round(p["o"] / fps * SR))
        t1_out = int(round((p["o"] + (p["e"] - p["s"] + 1)) / fps * SR))
        src0 = int(round(p["s"] / fps * SR))
        # окно: расширяем на HW в местах жёсткого стыка (берём реальные сэмплы вокруг реза)
        ext_in = HW if (i > 0 and p["n_in"] == 0) else 0
        ext_out = HW if (i < len(plan) - 1 and p["n_out"] == 0) else 0
        a0, a1 = t0_out - ext_in, t1_out + ext_out
        s0 = src0 - ext_in
        idx_src = np.arange(a0, a1) - t0_out + src0
        valid = (idx_src >= 0) & (idx_src < len(au)) & (np.arange(a0, a1) >= 0)
        chunk = np.zeros((a1 - a0, 2), np.float32)
        chunk[valid] = au[idx_src[valid]] * g
        w = np.ones(a1 - a0, np.float32)
        # входной фейд
        if i > 0:
            L = int(round(p["n_in"] / fps * SR)) if p["n_in"] > 0 else 2 * HW
            L = min(L, len(w))
            fi = np.sin(np.linspace(0, np.pi / 2, L, dtype=np.float32))
            w[:L] *= fi
        if i < len(plan) - 1:
            L = int(round(p["n_out"] / fps * SR)) if p["n_out"] > 0 else 2 * HW
            L = min(L, len(w))
            fo = np.cos(np.linspace(0, np.pi / 2, L, dtype=np.float32))
            w[-L:] *= fo
        chunk *= w[:, None]
        lo = max(a0, 0); hi = min(a1, len(out))
        out[lo:hi] += chunk[lo - a0: hi - a0]
    return out[:total]

def write_wav(path, x):
    import wave
    y = np.clip(x, -1, 1)
    y = (y * 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(y.tobytes())

def loudnorm_mux(video, audio_wav, out, lufs, fade_out_s=0.0, total_s=None):
    af_base = "aresample=48000"
    if fade_out_s and total_s:
        af_base += f",afade=t=out:st={max(0,total_s-fade_out_s):.2f}:d={fade_out_s}"
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(audio_wav), "-af", f"{af_base},loudnorm=I={lufs}:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"], capture_output=True, text=True)
    txt = r.stderr[r.stderr.rfind("{"): r.stderr.rfind("}") + 1]
    m = json.loads(txt)
    ln = (f"loudnorm=I={lufs}:TP=-1.5:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}:"
          f"measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true")
    core.sh(["ffmpeg", "-y", "-v", "error", "-i", str(video), "-i", str(audio_wav), "-map", "0:v", "-map", "1:a", "-c:v", "copy",
             "-af", f"{af_base},{ln}", "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-shortest", "-movflags", "+faststart", str(out)])
    return {"measured_input_lufs": float(m["input_i"]), "target_lufs": lufs}

def music_bed(music, voice, total_s, wav_out, gain_db, work):
    """Единая непрерывная музыка (зацикливание/обрезка, фейды), опц. голос с дакингом."""
    fil = f"[0:a]aloop=loop=-1:size=2000000000,atrim=0:{total_s:.3f},volume={gain_db}dB,afade=t=in:d=0.6,afade=t=out:st={max(0,total_s-1.2):.2f}:d=1.2[m]"
    cmd = ["ffmpeg", "-y", "-v", "error", "-i", str(music)]
    if voice:
        cmd += ["-i", str(voice)]
        fil += ";[1:a]apad,atrim=0:%.3f[v];[m][v]sidechaincompress=threshold=0.05:ratio=8:attack=20:release=400[md];[md][v]amix=inputs=2:normalize=0[o]" % total_s
        mapo = "[o]"
    else:
        mapo = "[m]"
    cmd += ["-filter_complex", fil, "-map", mapo, "-ac", "2", "-ar", str(SR), str(wav_out)]
    core.sh(cmd)

# ---------- основной ----------
def stitch(segments, out, cfg=None, work=None, ctx=None):
    cfg = {**DEF, **(cfg or {})}
    segments = [Path(s) for s in segments]
    out = Path(out); out.parent.mkdir(parents=True, exist_ok=True)
    work = Path(work or out.parent / "_work"); work.mkdir(parents=True, exist_ok=True)
    infos = [core.probe(s) for s in segments]
    # целевые параметры
    W, H, F = cfg["width"], cfg["height"], cfg["fps"]
    if not (W and H):
        w0, h0 = infos[0]["width"], infos[0]["height"]
        sc = min(1.0, cfg["max_long_side"] / max(w0, h0))
        W, H = int(round(w0 * sc / 2)) * 2, int(round(h0 * sc / 2)) * 2
    if not F:
        F = int(round(infos[0]["fps"])) or 24
        F = min(max(F, 24), 30)
    fps = F
    rep = {"target": f"{W}x{H}@{fps}", "inputs": [{"file": str(s), **i} for s, i in zip(segments, infos)], "joints": []}
    # 1) анализ (малые кадры) + цвет
    S = [read_all_small(s, W, H, fps, cfg["small_w"]) for s in segments]
    Ts = [None]
    S_corr = [S[0]]
    for i in range(1, len(S)):
        tail = S_corr[-1][-5:]; head = S[i][:5]
        dE_before = delta_lab(tail[-1], head[0])
        T = None
        if cfg["color_match"] and dE_before > cfg["de_shift_min"]:
            T = make_T(head, tail)
        Ts.append(T)
        Si = np.stack([apply_T(f, T) for f in S[i]]) if T else S[i]
        S_corr.append(Si)
        rep["joints"].append({"joint": i, "dE_lab_before": round(dE_before, 2), "dE_lab_after": round(delta_lab(tail[-1], Si[0]), 2), "color_corrected": T is not None})
    # 2) подбор стыков
    K = max(2, int(cfg["cut_search_s"] * fps))
    mot = [motion_series(s) for s in S_corr]
    cuts = []
    for i in range(len(S) - 1):
        c = find_cut(S_corr[i], S_corr[i + 1], mot[i], mot[i + 1], K, fps)
        # порог «чистого» стыка относительно обычной разницы соседних кадров
        base = float(np.median([((S_corr[i][k].astype(np.float32) - S_corr[i][k - 1].astype(np.float32)) ** 2).mean() for k in range(1, len(S_corr[i]))] or [1.0]))
        thr = max(cfg["hard_mse_floor"], 3.0 * base)
        if c["mse"] <= thr:
            n = 0
        else:
            n = int(min(cfg["xfade_max_s"] * fps, max(3, round(fps * 0.12 * (c["mse"] / thr)))))
        c.update(n=n, thr=round(thr, 2))
        cuts.append(c)
        rep["joints"][i].update(cut_a=c["a"], cut_b=c["b"], mse=round(c["mse"], 2), thr=c["thr"], mot_diff=round(c["dm"], 2), trimmed_frames=c["trim"], crossfade_frames=n, type=("xfade" if n else "hard-cut"))
    # 3) план диапазонов
    plan = []
    for i, nfr in enumerate([len(s) for s in S]):
        s_i = cuts[i - 1]["b"] + 1 if i > 0 else 0
        e_i = cuts[i]["a"] if i < len(S) - 1 else nfr - 1
        n_in = cuts[i - 1]["n"] if i > 0 else 0
        n_out = cuts[i]["n"] if i < len(S) - 1 else 0
        plan.append(dict(s=s_i, e=e_i, n_in=n_in, n_out=n_out))
    for i, p in enumerate(plan):   # безопасность длины
        L = p["e"] - p["s"] + 1
        if p["n_in"] + p["n_out"] > L - 1:
            k = max(0, (L - 1) // 2)
            p["n_in"] = min(p["n_in"], k); p["n_out"] = min(p["n_out"], k)
            if i > 0: plan[i - 1]["n_out"] = p["n_in"]
            if i < len(plan) - 1: plan[i + 1]["n_in"] = p["n_out"]
    o = 0
    for i, p in enumerate(plan):
        p["o"] = o
        o += (p["e"] - p["s"] + 1) - p["n_out"]
    total_frames = plan[-1]["o"] + (plan[-1]["e"] - plan[-1]["s"] + 1)
    for j in range(len(plan) - 1):
        rep["joints"][j]["out_frame"] = plan[j + 1]["o"]
        rep["joints"][j]["crossfade_frames"] = plan[j + 1]["n_in"]
    # 4) рендер
    raw = work / "video_noaudio.mp4"
    vf = []
    if cfg["deflicker"]: vf = ["-vf", "deflicker=size=5:mode=am"]
    enc = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{W}x{H}", "-r", str(fps), "-i", "-"] + vf +
                           ["-c:v", "libx264", "-preset", cfg["preset"], "-crf", str(cfg["crf"]), "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(raw)],
                           stdin=subprocess.PIPE)
    written = 0
    pending = []
    for i, seg in enumerate(segments):
        p = plan[i]; T = Ts[i]
        length = p["e"] - p["s"] + 1
        n_in, n_out = p["n_in"], p["n_out"]
        hold = []
        for k, f in enumerate(read_frames(seg, W, H, fps)):
            if k < p["s"]: continue
            if k > p["e"]: break
            fr = apply_T(f, T) if (T is not None and cfg["color_match"]) else np.array(f)
            kk = k - p["s"]
            if kk < n_in and kk < len(pending):
                alpha = (kk + 1) / (n_in + 1)
                enc.stdin.write(cv2.addWeighted(pending[kk], 1 - alpha, fr, alpha, 0).tobytes()); written += 1
            elif n_out > 0 and kk >= length - n_out:
                hold.append(fr)
            else:
                enc.stdin.write(fr.tobytes()); written += 1
        pending = hold
    enc.stdin.close(); enc.wait()
    rep["frames_written"] = written
    rep["frames_planned"] = total_frames
    dur = written / fps
    # 5) звук
    mode = cfg["audio"]
    has = [i["has_audio"] for i in infos]
    if mode == "auto":
        mode = "segments" if any(has) else ("music" if cfg["music"] else "mute")
        if any(has) and not all(has): rep["audio_warning"] = "часть клипов без звука — на их месте тишина; для ровного звука задайте --music/audio: music"
    rep["audio_mode"] = mode
    final_noup = out.with_name(out.stem + ("_pre_upscale" if cfg["upscale"] != "none" else "") + ".mp4") if cfg["upscale"] != "none" else out
    if mode == "mute":
        core.sh(["ffmpeg", "-y", "-v", "error", "-i", str(raw), "-c:v", "copy", "-an", str(final_noup)])
    else:
        wav = work / "audio.wav"
        if mode == "segments":
            auds = [read_audio(s) for s in segments]
            mix = build_audio_from_segments(auds, plan, fps, written)
            write_wav(wav, mix)
        else:
            music_bed(cfg["music"], cfg["voice"], dur, wav, cfg["music_gain_db"], work)
        rep["loudnorm"] = loudnorm_mux(raw, wav, final_noup, cfg["lufs"], fade_out_s=(0.8 if mode == "music" else 0.0), total_s=dur)
    rep["duration_s"] = round(dur, 2)
    # 6) апскейл
    if cfg["upscale"] == "lanczos":
        bw, bh = map(int, cfg["upscale_target"].split("x"))
        k = min(bw / W, bh / H) if W >= H or True else 1
        tw, th = int(round(W * k / 2)) * 2, int(round(H * k / 2)) * 2      # вписываем в рамку с сохранением пропорций
        core.sh(["ffmpeg", "-y", "-v", "error", "-i", str(final_noup), "-vf", f"scale={tw}:{th}:flags=lanczos,unsharp=5:5:0.4:3:3:0.0", "-c:v", "libx264", "-preset", "medium", "-crf", "15", "-pix_fmt", "yuv420p", "-c:a", "copy", str(out)])
        rep["upscale"] = {"mode": "lanczos", "note": f"ffmpeg lanczos до {tw}x{th} (НЕ AI-апскейл — детали не добавляются)"}
    elif cfg["upscale"] == "fal":
        rep["upscale"] = upscale_fal(ctx, final_noup, out, cfg, W, H, fps, dur)
    rep["output"] = str(out)
    rep["plan"] = plan
    (out.with_suffix(".stitch.json")).write_text(json.dumps(rep, ensure_ascii=False, indent=1, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o)))
    return rep

def upscale_fal(ctx, src, out, cfg, W, H, fps, dur):
    key, m = ctx.reg.role("upscale_video")
    tw, th = map(int, cfg["upscale_target"].split("x"))
    mpf = tw * th / 1e6 * (round(dur * fps))
    est = core.unit_price(m, megapixel_frames=mpf)
    fixed = m.get("fixed", {})
    res, url, usd, hit = core.call(ctx, key, {"video": Path(src)}, tag="upscale", est=est, mp_frames=mpf,
                                   extra={"target_resolution": {2160: "2160p", 1440: "1440p", 1080: "1080p", 720: "720p"}.get(th, fixed.get("target_resolution", "2160p"))})
    core.download(url, out)
    # звук: апскейлер может не вернуть дорожку — берём из исходника
    pi = core.probe(out)
    if not pi["has_audio"] and core.probe(src)["has_audio"]:
        tmp = Path(out).with_suffix(".na.mp4"); Path(out).replace(tmp)
        core.sh(["ffmpeg", "-y", "-v", "error", "-i", str(tmp), "-i", str(src), "-map", "0:v", "-map", "1:a", "-c", "copy", "-shortest", str(out)]); tmp.unlink()
    return {"mode": "fal", "model": key, "usd": round(usd, 4), "out": core.probe(out)}

# ---------- отчёт по швам ----------
def seam_report(video, joints_out_frames, outdir, label="seam", before=3, after=3, cell_w=360):
    """Вытаскивает кадры вокруг стыков (ffmpeg), собирает контактные листы и считает метрики разрыва."""
    from PIL import Image, ImageDraw, ImageFont
    outdir = Path(outdir); outdir.mkdir(parents=True, exist_ok=True)
    info = core.probe(video)
    cap = cv2.VideoCapture(str(video))
    frames = []
    while True:
        ok, f = cap.read()
        if not ok: break
        frames.append(f)
    cap.release()
    g = [cv2.cvtColor(cv2.resize(f, (192, int(192 * f.shape[0] / f.shape[1]))), cv2.COLOR_BGR2GRAY).astype(np.float32) for f in frames]
    diffs = np.array([((g[k] - g[k - 1]) ** 2).mean() for k in range(1, len(g))])
    luma = np.array([x.mean() for x in g])
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 15)
    report = {"video": str(video), "frames": len(frames), "fps": info["fps"], "joints": []}
    for j, J in enumerate(joints_out_frames):
        lo, hi = max(0, J - before), min(len(frames) - 1, J + after - 1)
        idxs = list(range(lo, hi + 1))
        h = int(cell_w * frames[0].shape[0] / frames[0].shape[1])
        sheet = Image.new("RGB", (cell_w * len(idxs), h + 24), (15, 15, 15))
        d = ImageDraw.Draw(sheet)
        for c, k in enumerate(idxs):
            im = Image.fromarray(cv2.cvtColor(cv2.resize(frames[k], (cell_w, h), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB))
            sheet.paste(im, (c * cell_w, 24))
            d.text((c * cell_w + 6, 3), f"кадр {k}" + ("  <-- стык" if k == J else ""), fill=(255, 220, 90) if k == J else (220, 220, 220), font=font)
        p = outdir / f"{label}_joint{j+1}_f{J}.png"
        sheet.save(p)
        a, b = max(1, J - 15), min(len(diffs), J + 15)
        ctx_d = np.concatenate([diffs[a - 1:J - 2 if J - 2 > a else a], diffs[J + 1:b]]) if b > a else diffs
        med = float(np.median(diffs[a - 1:b])) if b > a else 0.0
        jd = float(diffs[J - 1]) if 1 <= J <= len(diffs) else float("nan")
        mx = float(np.max(diffs[max(0, J - 3):J + 2])) if len(diffs) else 0.0
        report["joints"].append({"joint": j + 1, "frame": J, "sheet": str(p), "frame_diff_at_joint": round(jd, 2), "max_diff_near_joint": round(mx, 2),
                                 "median_diff_nearby": round(med, 2), "ratio": round(mx / max(med, 0.5), 2),
                                 "luma_step": round(float(abs(luma[min(J, len(luma) - 1)] - luma[max(J - 1, 0)])), 2)})
    # метрика мерцания: std второй разности яркости (по всему ролику)
    if len(luma) > 3:
        report["luma_flicker_std"] = round(float(np.std(np.diff(luma, 2))), 3)
    (outdir / f"{label}_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1))
    return report
