#!/usr/bin/env python3
"""studio — производственный конвейер. Запуск: studio.py estimate|run|plan|stitch|tiers|report ..."""
import sys, os, json, argparse
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from lib import core

def jobpath(p):
    p = Path(p)
    if p.is_dir(): p = p / "job.yaml"
    if not p.exists(): p = ROOT / "jobs" / str(p) / "job.yaml"
    return p

def cmd_estimate(a):
    from lib import estimate
    ctx = core.Ctx(jobpath(a.job)); estimate.print_estimate(ctx)

def cmd_plan(a):
    from lib import reels_planner
    ctx = core.Ctx(jobpath(a.job), go=a.go)
    r = reels_planner.plan(ctx)
    print(f"календарь: {len(r['reels'])} роликов, lint-нарушений: {r['lint_fail']}, usd {r['usd']:.3f} -> {r['dir']}")

STAGES = ["enhance", "zones", "plan", "reels", "hero", "minis", "continue"]

def cmd_run(a):
    from lib import estimate, photo_enhance, zones, reels_planner, pipelines
    ctx = core.Ctx(jobpath(a.job), go=a.go, workers=a.workers)
    tot = estimate.print_estimate(ctx)
    if not a.go:
        print("\nDRY-RUN: ничего не потрачено. Платный прогон: studio.py run <job> --go (нужен budget_usd > 0 в job.yaml)."); return
    if ctx.budget.cap <= 0:
        print("СТОП: budget_usd=0 в job.yaml. Задайте потолок > 0 и повторите с --go."); sys.exit(2)
    stages = a.stages.split(",") if a.stages else [s for s, k in (("enhance", "enhance"), ("zones", "zones"), ("plan", "reels"), ("reels", "reels"), ("hero", "hero_videos"), ("minis", "minis"), ("continue", "continue")) if k in ctx.job]
    results = {}
    try:
        for s in stages:
            print(f"\n=== этап {s} ===")
            if s == "enhance": results[s] = photo_enhance.run(ctx)
            elif s == "zones": results[s] = zones.run(ctx)
            elif s == "plan": results[s] = {"lint_fail": reels_planner.plan(ctx)["lint_fail"]}
            elif s == "reels": results[s] = pipelines.run_reels(ctx)
            elif s == "hero": results[s] = pipelines.run_hero(ctx)
            elif s == "minis": results[s] = pipelines.run_minis(ctx)
            elif s == "continue": results[s] = pipelines.run_continue(ctx)
    except core.BudgetExceeded as e:
        print(f"\nОСТАНОВ ПО БЮДЖЕТУ: {e}"); results["stopped_by_budget"] = str(e)
    rep = ctx.budget.report()
    (ctx.out / "report.json").write_text(json.dumps({"results": results, "budget": rep}, ensure_ascii=False, indent=1, default=str))
    print("\n=== ОТЧЁТ ПО РАСХОДАМ ===")
    print(json.dumps(rep, ensure_ascii=False, indent=1))

def cmd_stitch(a):
    from lib import stitch
    cfg = {"audio": a.audio, "upscale": a.upscale, "music": a.music}
    rep = stitch.stitch(a.inputs, a.out, cfg, work=Path(a.out).parent / "_work")
    joints = [j["out_frame"] for j in rep["joints"] if "out_frame" in j]
    sr = stitch.seam_report(a.out, joints, Path(a.out).parent / "seams", label=Path(a.out).stem) if joints else None
    print(json.dumps({"out": rep["output"], "duration_s": rep["duration_s"], "joints": rep["joints"], "seam_metrics": sr and sr["joints"]}, ensure_ascii=False, indent=1))

def cmd_tiers(a):
    from lib import tiers
    tiers.write_markdown(ROOT / "ESTIMATES.md"); print("ESTIMATES.md обновлён")

def cmd_report(a):
    ctx = core.Ctx(jobpath(a.job)); print(json.dumps(ctx.budget.report(), ensure_ascii=False, indent=1))

def main():
    ap = argparse.ArgumentParser(prog="studio")
    sp = ap.add_subparsers(dest="cmd", required=True)
    p = sp.add_parser("estimate"); p.add_argument("job"); p.set_defaults(f=cmd_estimate)
    p = sp.add_parser("plan"); p.add_argument("job"); p.add_argument("--go", action="store_true"); p.set_defaults(f=cmd_plan)
    p = sp.add_parser("run"); p.add_argument("job"); p.add_argument("--go", action="store_true", help="платный прогон (нужен budget_usd>0)")
    p.add_argument("--stages", help="через запятую: " + ",".join(STAGES)); p.add_argument("--workers", type=int); p.set_defaults(f=cmd_run)
    p = sp.add_parser("stitch", help="склеить клипы (локально, $0)"); p.add_argument("inputs", nargs="+"); p.add_argument("--out", required=True)
    p.add_argument("--audio", default="auto"); p.add_argument("--upscale", default="none"); p.add_argument("--music"); p.set_defaults(f=cmd_stitch)
    p = sp.add_parser("tiers"); p.set_defaults(f=cmd_tiers)
    p = sp.add_parser("report"); p.add_argument("job"); p.set_defaults(f=cmd_report)
    a = ap.parse_args(); a.f(a)

if __name__ == "__main__":
    main()
